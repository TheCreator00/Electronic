'name': file_name,
            'path': dest_path,
            'preview_path': preview_path,
            'type': file_type
        }
    
    def create_preview(self, file_path, unique_id):
        import os
        from PIL import Image
        import pdf2image
        
        # Ruta para la vista previa
        preview_path = os.path.join(self.previews_dir, f"{unique_id}_preview.png")
        
        # Obtener extensión del archivo
        file_ext = os.path.splitext(file_path)[1].lower()
        
        try:
            # Si es una imagen, redimensionar para crear la vista previa
            if file_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.gif']:
                with Image.open(file_path) as img:
                    # Redimensionar manteniendo la proporción
                    img.thumbnail((400, 300))
                    # Guardar como vista previa
                    img.save(preview_path)
            
            # Si es un PDF, convertir la primera página a imagen
            elif file_ext == '.pdf':
                # Convertir primera página del PDF a imagen
                pages = pdf2image.convert_from_path(file_path, dpi=100, first_page=1, last_page=1)
                if pages:
                    # Redimensionar y guardar la primera página
                    pages[0].thumbnail((400, 300))
                    pages[0].save(preview_path)
                else:
                    # Si no se puede convertir, usar una imagen de placeholder
                    shutil.copy('assets/placeholder.png', preview_path)
            
            # Para otros tipos de archivo, usar una imagen de placeholder
            else:
                import shutil
                shutil.copy('assets/placeholder.png', preview_path)
            
            return preview_path
        
        except Exception as e:
            print(f"Error al crear vista previa: {str(e)}")
            # En caso de error, devolver la ruta al placeholder
            return 'assets/placeholder.png'
    
    def determine_file_type(self, extension):
        # Mapeo de extensiones a tipos de archivo
        type_mapping = {
            '.pdf': 'PDF Document',
            '.jpg': 'JPEG Image',
            '.jpeg': 'JPEG Image',
            '.png': 'PNG Image',
            '.bmp': 'Bitmap Image',
            '.gif': 'GIF Image'
        }
        
        return type_mapping.get(extension.lower(), 'Unknown')

# Módulo para análisis con IA
# ai_analyzer.py
class AIAnalyzer:
    def __init__(self):
        import os
        import tensorflow as tf
        import cv2
        import numpy as np
        
        # Cargar el modelo de TensorFlow (esto es un ejemplo, tendrías que crear/entrenar tu modelo)
        self.load_model()
    
    def load_model(self):
        import tensorflow as tf
        
        try:
            # Intentar cargar un modelo existente
            self.model = tf.keras.models.load_model('models/electronic_components_model')
            print("Modelo cargado exitosamente")
        except:
            # Si el modelo no existe, crear uno simple para demostracion
            print("Creando modelo de ejemplo...")
            self.create_demo_model()
    
    def create_demo_model(self):
        import tensorflow as tf
        import os
        import numpy as np
        
        # Este es un modelo muy simple para demostración, no es funcional para detección real
        # En una implementación real, necesitarías un modelo adecuado entrenado para este propósito
        inputs = tf.keras.Input(shape=(224, 224, 3))
        x = tf.keras.layers.Conv2D(32, 3, activation='relu')(inputs)
        x = tf.keras.layers.MaxPooling2D()(x)
        x = tf.keras.layers.Conv2D(64, 3, activation='relu')(x)
        x = tf.keras.layers.MaxPooling2D()(x)
        x = tf.keras.layers.Conv2D(128, 3, activation='relu')(x)
        x = tf.keras.layers.MaxPooling2D()(x)
        x = tf.keras.layers.Flatten()(x)
        x = tf.keras.layers.Dense(128, activation='relu')(x)
        outputs = tf.keras.layers.Dense(10, activation='softmax')(x)
        
        self.model = tf.keras.Model(inputs, outputs)
        self.model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        # Crear directorio para el modelo si no existe
        if not os.path.exists('models'):
            os.makedirs('models')
        
        # Guardar el modelo
        self.model.save('models/electronic_components_model')
        
        # Lista de componentes que puede "detectar" nuestro modelo de demostración
        self.component_classes = [
            'resistor', 'capacitor', 'diode', 'transistor', 'inductor',
            'integrated_circuit', 'led', 'switch', 'connector', 'transformer'
        ]
    
    def process_image(self, image_path):
        import cv2
        import numpy as np
        
        # Leer la imagen
        image = cv2.imread(image_path)
        if image is None:
            raise Exception(f"No se pudo leer la imagen: {image_path}")
        
        # Redimensionar para el modelo
        resized = cv2.resize(image, (224, 224))
        
        # Convertir a RGB si es necesario (OpenCV usa BGR por defecto)
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        
        # Normalizar
        normalized = rgb / 255.0
        
        # Expandir dimensiones para que coincida con la entrada del modelo
        return np.expand_dims(normalized, axis=0), image
    
    def analyze_file(self, file_path):
        import cv2
        import numpy as np
        import os
        from PIL import Image
        import pdf2image
        import random  # Para el demo
        
        # Determinar el tipo de archivo
        file_ext = os.path.splitext(file_path)[1].lower()
        
        # Procesar según el tipo
        if file_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.gif']:
            return self.analyze_image(file_path)
        elif file_ext == '.pdf':
            # Convertir primera página a imagen
            pages = pdf2image.convert_from_path(file_path, dpi=150, first_page=1, last_page=1)
            if not pages:
                raise Exception("No se pudo convertir el PDF a imagen")
            
            # Guardar temporalmente la imagen
            temp_image_path = 'temp_pdf_image.png'
            pages[0].save(temp_image_path)
            
            # Analizar la imagen
            results = self.analyze_image(temp_image_path)
            
            # Eliminar la imagen temporal
            os.remove(temp_image_path)
            
            return results
        else:
            raise Exception(f"Formato de archivo no soportado: {file_ext}")
    
    def analyze_image(self, image_path):
        import cv2
        import numpy as np
        import random  # Para el demo
        
        # En una implementación real, procesarías la imagen con tu modelo
        try:
            # Procesar la imagen
            input_tensor, original_image = self.process_image(image_path)
            
            # En un escenario real, aquí realizarías la detección de objetos
            # Para este demo, generamos resultados aleatorios
            
            # Número de componentes a "detectar" (aleatorio para demostración)
            num_components = random.randint(3, 8)
            
            # Altura y anchura de la imagen original
            height, width = original_image.shape[:2]
            
            components = []
            for _ in range(num_components):
                # Elegir un tipo de componente aleatorio
                component_type = random.choice(self.component_classes)
                
                # Generar un cuadro delimitador aleatorio
                x = random.randint(10, width - 100)
                y = random.randint(10, height - 100)
                w = random.randint(50, min(200, width - x - 10))
                h = random.randint(50, min(200, height - y - 10))
                
                # Generar una confianza aleatoria
                confidence = random.uniform(0.7, 0.99)
                
                components.append({
                    'type': component_type,
                    'confidence': confidence,
                    'box': [x, y, w, h]
                })
            
            # En una implementación real, aquí generarías información adicional
            # basada en el análisis, como las conexiones entre componentes
            
            # Generar "conexiones" aleatorias para demostración
            connections = []
            if len(components) >= 2:
                num_connections = random.randint(1, min(5, len(components) - 1))
                for _ in range(num_connections):
                    comp1 = random.choice(components)
                    comp2 = random.choice([c for c in components if c != comp1])
                    
                    connections.append({
                        'from': components.index(comp1),
                        'to': components.index(comp2),
                        'type': random.choice(['direct', 'via_wire', 'via_pcb'])
                    })
            
            # Resultados del análisis
            results = {
                'components': components,
                'connections': connections,
                'image_size': {'width': width, 'height': height}
            }
            
            return results
            
        except Exception as e:
            raise Exception(f"Error en el análisis de imagen: {str(e)}")

# Módulo para visualización de resultados
# visualization.py
class ResultVisualizer:
    def __init__(self):
        import os
        
        self.results_dir = 'results'
        self.exports_dir = 'exports'
    
    def visualize_results(self, results, original_image_path):
        import cv2
        import numpy as np
        import os
        import uuid
        
        # Generar un nombre único para el archivo de resultados
        result_id = str(uuid.uuid4())
        result_image_path = os.path.join(self.results_dir, f"{result_id}_result.png")
        
        try:
            # Leer la imagen original
            original_image = cv2.imread(original_image_path)
            if original_image is None:
                raise Exception(f"No se pudo leer la imagen original: {original_image_path}")
            
            # Crear una copia para no modificar la original
            result_image = original_image.copy()
            
            # Dibujar los componentes detectados
            for component in results['components']:
                # Extraer información del componente
                box = component['box']  # [x, y, w, h]
                component_type = component['type']
                confidence = component['confidence']
                
                # Determinar color según el tipo de componente
                color_map = {
                    'resistor': (0, 255, 0),       # Verde
                    'capacitor': (255, 0, 0),      # Azul (BGR)
                    'diode': (0, 0, 255),          # Rojo
                    'transistor': (255, 255, 0),   # Cian
                    'inductor': (255, 0, 255),     # Magenta
                    'integrated_circuit': (0, 255, 255),  # Amarillo
                    'led': (128, 0, 128),          # Púrpura
                    'switch': (0, 128, 255),       # Naranja
                    'connector': (128, 128, 0),    # Azul oscuro
                    'transformer': (0, 128, 128)   # Marrón
                }
                
                color = color_map.get(component_type, (200, 200, 200))
                
                # Dibujar rectángulo
                cv2.rectangle(
                    result_image,
                    (box[0], box[1]),
                    (box[0] + box[2], box[1] + box[3]),
                    color,
                    2
                )
                
                # Añadir etiqueta
                label = f"{component_type} ({confidence:.2f})"
                cv2.putText(
                    result_image,
                    label,
                    (box[0], box[1] - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    color,
                    2
                )
            
            # Dibujar conexiones
            for connection in results['connections']:
                from_idx = connection['from']
                to_idx = connection['to']
                
                # Obtener los componentes conectados
                from_comp = results['components'][from_idx]
                to_comp = results['components'][to_idx]
                
                # Calcular puntos centrales de los componentes
                from_x = from_comp['box'][0] + from_comp['box'][2] // 2
                from_y = from_comp['box'][1] + from_comp['box'][3] // 2
                
                to_x = to_comp['box'][0] + to_comp['box'][2] // 2
                to_y = to_comp['box'][1] + to_comp['box'][3] // 2
                
                # Dibujar línea de conexión
                cv2.line(
                    result_image,
                    (from_x, from_y),
                    (to_x, to_y),
                    (120, 120, 120),  # Gris
                    1,
                    cv2.LINE_AA
                )
            
            # Guardar la imagen con los resultados
            cv2.imwrite(result_image_path, result_image)
            
            return result_image_path
            
        except Exception as e:
            print(f"Error en la visualización: {str(e)}")
            # En caso de error, devolver la imagen original
            return original_image_path
    
    def export_results(self, results, original_file_name):
        import os
        import json
        import uuid
        import datetime
        import cv2
        
        # Generar nombre de archivo para la exportación
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(original_file_name)[0]
        export_id = str(uuid.uuid4())[:8]
        
        # Crear directorio de exportación si no existe
        if not os.path.exists(self.exports_dir):
            os.makedirs(self.exports_dir)
        
        # Exportar a JSON
        json_path = os.path.join(self.exports_dir, f"{base_name}_{timestamp}_{export_id}.json")
        with open(json_path, 'w') as f:
            json.dump(results, f, indent=4)
        
        # También generar un informe en formato HTML para mejor visualización
        html_path = os.path.join(self.exports_dir, f"{base_name}_{timestamp}_{export_id}.html")
        
        # Generar HTML
        html_content = self.generate_html_report(results, original_file_name)
        
        # Guardar HTML
        with open(html_path, 'w') as f:
            f.write(html_content)
        
        return json_path
    
    def generate_html_report(self, results, original_file_name):
        # Generar un informe HTML con los resultados
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Análisis de Electrónica - {original_file_name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1 {{ color: #2c3e50; }}
                .summary {{ background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
                table {{ border-collapse: collapse; width: 100%; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #4CAF50; color: white; }}
                tr:nth-child(even) {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h1>Análisis de Electrónica</h1>
            <div class="summary">
                <h2>Resumen</h2>
                <p><strong>Archivo analizado:</strong> {original_file_name}</p>
                <p><strong>Fecha de análisis:</strong> {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
                <p><strong>Componentes detectados:</strong> {len(results['components'])}</p>
                <p><strong>Conexiones detectadas:</strong> {len(results['connections'])}</p>
            </div>
            
            <h2>Componentes Detectados</h2>
            <table>
                <tr>
                    <th>#</th>
                    <th>Tipo</th>
                    <th>Confianza</th>
                    <th>Posición (x, y)</th>
                    <th>Tamaño (w, h)</th>
                </tr>
        """
        
        # Añadir información de cada componente
        for i, component in enumerate(results['components']):
            html += f"""
                <tr>
                    <td>{i+1}</td>
                    <td>{component['type']}</td>
                    <td>{component['confidence']:.2f}</td>
                    <td>({component['box'][0]}, {component['box'][1]})</td>
                    <td>{component['box'][2]} x {component['box'][3]}</td>
                </tr>
            """
        
        html += """
            </table>
            
            <h2>Conexiones Detectadas</h2>
            <table>
                <tr>
                    <th>#</th>
                    <th>Desde Componente</th>
                    <th>Hasta Componente</th>
                    <th>Tipo de Conexión</th>
                </tr>
        """
        
        # Añadir información de cada conexión
        for i, connection in enumerate(results['connections']):
            from_type = results['components'][connection['from']]['type']
            to_type = results['components'][connection['to']]['type']
            
            html += f"""
                <tr>
                    <td>{i+1}</td>
                    <td>{from_type} (#{connection['from']+1})</td>
                    <td>{to_type} (#{connection['to']+1})</td>
                    <td>{connection['type']}</td>
                </tr>
            """
        
        html += """
            </table>
            
            <h2>Recomendaciones</h2>
            <ul>
                <li>Revise los componentes detectados para verificar su precisión.</li>
                <li>Compare las conexiones identificadas con el diagrama original.</li>
                <li>Para un análisis más detallado, considere exportar el archivo JSON.</li>
            </ul>
            
            <p><em>Generado por Electronic Analyzer App</em></p>
        </body>
        </html>
        """
        
        return html

# Punto de entrada principal
if __name__ == '__main__':
    ElectronicAnalyzerApp().run()
