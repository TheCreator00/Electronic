import OpenAI from "openai";
import { ChatRequest, ChatResponse, KnowledgeDocument } from "../shared/xaiTypes";

// Interfaz para la respuesta de estado de modelos
interface ModelStatusResponse {
  grok: boolean;
  local: boolean;
  hybrid: boolean;
  message: string;
}
import fs from "fs";
import path from "path";

// Inicializar el cliente de OpenAI con la URL base y key de xAI
// Si no hay API key disponible o es inválida, muchas operaciones usarán el modo local
const openai = new OpenAI({ 
  baseURL: "https://api.x.ai/v1", 
  apiKey: process.env.XAI_API_KEY || 'dummy-key',
  defaultQuery: { api_key: process.env.XAI_API_KEY || 'dummy-key' },
  defaultHeaders: { 'X-Api-Key': process.env.XAI_API_KEY || 'dummy-key' }
});

// Base de conocimientos en memoria
const knowledgeBase: KnowledgeDocument[] = [];

// Función auxiliar para guardar archivos
function saveBase64File(base64Data: string, fileName: string, folder: string): Promise<string> {
  return new Promise((resolve, reject) => {
    try {
      // Asegurarse de que la carpeta exista
      if (!fs.existsSync(folder)) {
        fs.mkdirSync(folder, { recursive: true });
      }

      // Generar un nombre de archivo único para evitar sobrescrituras
      const fileExt = path.extname(fileName);
      const baseName = path.basename(fileName, fileExt);
      const uniqueFileName = `${baseName}_${Date.now()}${fileExt}`;
      const filePath = path.join(folder, uniqueFileName);
      
      // Procesar datos según el formato
      if (base64Data.startsWith('data:')) {
        // Es una cadena de datos con formato data:URL
        const matches = base64Data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
        if (!matches || matches.length !== 3) {
          throw new Error('Invalid data URL format');
        }
        fs.writeFileSync(filePath, Buffer.from(matches[2], 'base64'));
      } else {
        // Es texto plano o base64 sin formato data:URL
        if (/^[A-Za-z0-9+/=]+$/.test(base64Data)) {
          // Parece ser base64 puro
          try {
            fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));
          } catch (e) {
            // Si falla como base64, guardar como texto
            fs.writeFileSync(filePath, base64Data, 'utf-8');
          }
        } else {
          // Es texto plano
          fs.writeFileSync(filePath, base64Data, 'utf-8');
        }
      }
      
      console.log(`Archivo guardado: ${filePath}`);
      resolve(filePath);
    } catch (error) {
      console.error("Error al guardar archivo:", error);
      reject(error);
    }
  });
}

// Función para extraer el texto de archivos
async function extractTextFromFile(filePath: string): Promise<string> {
  try {
    console.log(`Procesando archivo: ${filePath}`);
    
    // Archivo de texto
    if (filePath.endsWith('.txt')) {
      return fs.readFileSync(filePath, 'utf-8');
    } 
    // Archivo PDF - usamos Python con PyMuPDF (fitz)
    else if (filePath.endsWith('.pdf')) {
      // Usar un subproceso de Python para extraer texto de PDFs
      return new Promise((resolve, reject) => {
        const { spawn } = require('child_process');
        const pythonProcess = spawn('python', [
          '-c', 
          `
import sys
import fitz  # PyMuPDF

try:
    doc = fitz.open("${filePath.replace(/\\/g, '\\\\')}")
    text = ""
    for page in doc:
        text += page.get_text()
    print(text)
except Exception as e:
    print(f"Error processing PDF: {str(e)}")
          `
        ]);
        
        let textOutput = '';
        let errorOutput = '';
        
        pythonProcess.stdout.on('data', (data) => {
          textOutput += data.toString();
        });
        
        pythonProcess.stderr.on('data', (data) => {
          errorOutput += data.toString();
        });
        
        pythonProcess.on('close', (code) => {
          if (code !== 0) {
            console.error(`Python process exited with code ${code}: ${errorOutput}`);
            resolve(`No se pudo extraer texto del PDF. Error: ${errorOutput}`);
          } else if (errorOutput.includes("Error processing PDF")) {
            console.error(`Error en Python al procesar PDF: ${errorOutput}`);
            resolve(`No se pudo extraer texto del PDF. Error: ${errorOutput}`);
          } else {
            resolve(textOutput);
          }
        });
      });
    } 
    // Archivos Word, no implementado
    else if (filePath.includes('.doc')) {
      return "Contenido extraído del DOC " + filePath + ". Para mejor procesamiento, considere convertir a PDF o texto.";
    } 
    // Imágenes - podemos usar la API de xAI para describirlas
    else if (filePath.match(/\.(jpe?g|png|gif|webp)$/i)) {
      try {
        // Leer la imagen como base64
        const imageData = fs.readFileSync(filePath);
        const base64Image = imageData.toString('base64');
        
        // Usar la API de xAI para analizar la imagen
        if (process.env.XAI_API_KEY) {
          const response = await openai.chat.completions.create({
            model: "grok-2-vision-1212",
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: "Analiza esta imagen de componente o circuito electrónico. Describe en detalle qué ves, identificando los componentes visibles y sus posibles conexiones. Enfócate en aspectos técnicos de relevancia para el análisis de circuitos electrónicos."
                  },
                  {
                    type: "image_url",
                    image_url: {
                      url: `data:image/jpeg;base64,${base64Image}`
                    }
                  }
                ]
              }
            ]
          });
          
          return response.choices[0].message.content || 
                 "No se pudo obtener una descripción clara de la imagen.";
        } else {
          return "No hay API configurada para analizar imágenes. La imagen se archivó para referencia.";
        }
      } catch (imgError) {
        console.error("Error analyzing image:", imgError);
        return "Error al analizar la imagen. La imagen se archivó para referencia.";
      }
    }
    
    return "Archivo guardado pero no se pudo extraer contenido del formato: " + filePath;
  } catch (error) {
    console.error("Error extracting text from file:", error);
    return "Error al procesar el archivo " + filePath;
  }
}

// Función para añadir un documento a la base de conocimientos
export async function addKnowledgeDocument(doc: KnowledgeDocument, fileData?: string): Promise<KnowledgeDocument> {
  try {
    // Si se proporciona contenido de archivo, procesarlo
    if (fileData) {
      // Para imágenes y binarios, guardar el archivo
      if (doc.type === 'image' || fileData.startsWith('data:')) {
        const uploadFolder = path.join(process.cwd(), 'uploads');
        const filePath = await saveBase64File(fileData, doc.name, uploadFolder);
        doc.path = filePath;
      }

      // Extraer contenido para texto, doc, pdf
      if (['txt', 'pdf', 'doc'].includes(doc.type)) {
        if (fileData.startsWith('data:')) {
          // Guardar primero y luego extraer texto
          const uploadFolder = path.join(process.cwd(), 'uploads');
          const filePath = await saveBase64File(fileData, doc.name, uploadFolder);
          doc.path = filePath;
          doc.content = await extractTextFromFile(filePath);
        } else {
          // Ya es texto plano
          doc.content = fileData;
          doc.path = `memory://${doc.id}`;
        }
      }
    }

    // Cambiar estado a listo
    doc.status = 'ready';
    knowledgeBase.push(doc);
    
    return doc;
  } catch (error) {
    console.error("Error adding document to knowledge base:", error);
    doc.status = 'error';
    knowledgeBase.push(doc);
    return doc;
  }
}

// Función para obtener todos los documentos de la base de conocimientos
export function getKnowledgeDocuments(): KnowledgeDocument[] {
  // Devolver sin el contenido
  return knowledgeBase.map(doc => {
    const { content, ...docWithoutContent } = doc;
    return docWithoutContent;
  });
}

// Función para obtener un documento por ID
export function getKnowledgeDocumentById(id: string): KnowledgeDocument | undefined {
  return knowledgeBase.find(doc => doc.id === id);
}

// Función para eliminar un documento
export function removeKnowledgeDocument(id: string): boolean {
  const initialLength = knowledgeBase.length;
  const index = knowledgeBase.findIndex(doc => doc.id === id);
  
  if (index !== -1) {
    const doc = knowledgeBase[index];
    
    // Si tiene un archivo físico guardado, eliminarlo
    if (doc.path && doc.path.startsWith('/') && fs.existsSync(doc.path)) {
      try {
        fs.unlinkSync(doc.path);
      } catch (error) {
        console.error("Error deleting file:", error);
      }
    }
    
    knowledgeBase.splice(index, 1);
    return initialLength > knowledgeBase.length;
  }
  
  return false;
}

// Función principal para procesar una consulta de chat
export async function processChat(request: ChatRequest): Promise<ChatResponse> {
  try {
    // Manejar diferentes modelos
    if (request.model === 'local') {
      return processLocalChat(request);
    } else if (request.model === 'hybrid') {
      // Intentar local primero, si falla o tiene baja confianza, usar grok
      const localResponse = await processLocalChat(request);
      if (localResponse.confidence && localResponse.confidence < 0.7) {
        return processGrokChat(request);
      }
      return localResponse;
    } else {
      // Por defecto usar 'grok'
      return processGrokChat(request);
    }
  } catch (error) {
    console.error("Error in chat processing:", error);
    return {
      message: "Lo siento, ocurrió un error al procesar tu consulta. Por favor intenta de nuevo más tarde.",
      processingTime: 0,
      confidence: 0
    };
  }
}

// Procesar con modelo Grok (xAI)
async function processGrokChat(request: ChatRequest): Promise<ChatResponse> {
  const startTime = Date.now();
  
  try {
    // Construir el contenido del mensaje
    let context = "";
    const usedDocuments: string[] = [];
    
    // Incluir documentos de la base de conocimiento si se especifican
    if (request.documentIds && request.documentIds.length > 0) {
      for (const docId of request.documentIds) {
        const doc = getKnowledgeDocumentById(docId);
        if (doc && doc.content) {
          context += `\n\nDocumento: ${doc.name}\n${doc.content}`;
          usedDocuments.push(docId);
        }
      }
    } else {
      // Si no se especifican documentos, buscar por relevancia usando keywords
      const keywords = extractKeywords(request.message);
      const relevantDocs = findRelevantDocuments(keywords);
      
      relevantDocs.forEach(doc => {
        if (doc.content) {
          context += `\n\nDocumento: ${doc.name}\n${doc.content}`;
          usedDocuments.push(doc.id);
        }
      });
    }
    
    // Preparar el mensaje para el API
    const messages = [
      {
        role: "system",
        content: 
          "Eres un experto en electrónica que ayuda a analizar componentes y circuitos electrónicos. " + 
          "Proporciona respuestas precisas y técnicamente correctas, pero también accesibles. " +
          "Si te proporcionan documentos relevantes para la consulta, úsalos como referencia para mejorar tus respuestas." +
          (context ? "\n\nDocumentación de referencia:" + context : "")
      },
      {
        role: "user",
        content: request.message
      }
    ];
    
    // Si hay imágenes adjuntas, usamos el modelo de visión
    const hasImages = request.attachments?.some(att => att.type === 'image');
    const model = hasImages ? "grok-2-vision-1212" : "grok-2-1212";
    
    // Si hay imágenes, construir el mensaje con contenido multimodal
    if (hasImages) {
      const imageAttachments = request.attachments?.filter(att => att.type === 'image') || [];
      
      if (imageAttachments.length > 0) {
        // Reestructurar el mensaje para incluir imágenes
        const userMessage: any = {
          role: "user",
          content: [
            {
              type: "text",
              text: request.message
            }
          ]
        };
        
        // Añadir cada imagen al mensaje
        imageAttachments.forEach(img => {
          userMessage.content.push({
            type: "image_url",
            image_url: {
              url: img.data
            }
          });
        });
        
        // Reemplazar el mensaje de usuario simple con el multimodal
        messages[1] = userMessage;
      }
    }
    
    // Realizar la consulta a la API
    const response = await openai.chat.completions.create({
      model: model,
      messages: messages as any
    });
    
    const processingTime = Date.now() - startTime;
    
    return {
      message: response.choices[0].message.content || "No se obtuvo respuesta del modelo.",
      usedDocuments,
      processingTime,
      confidence: 0.95 // Alta confianza para respuestas de la API
    };
  } catch (error) {
    console.error("Error processing with Grok:", error);
    
    // Fallback si hay error con la API
    return {
      message: "Lo siento, ocurrió un error al procesar tu consulta con el modelo Grok. " +
               "Esto puede deberse a problemas de conexión con la API o a limitaciones del modelo.",
      processingTime: Date.now() - startTime,
      confidence: 0
    };
  }
}

// Procesamiento local básico basado en patrones y palabras clave
async function processLocalChat(request: ChatRequest): Promise<ChatResponse> {
  const startTime = Date.now();
  
  // Extraer palabras clave del mensaje
  const message = request.message.toLowerCase();
  let response = "";
  let confidence = 0.5; // Confianza media por defecto
  
  // Patrones básicos para preguntas frecuentes
  if (message.includes("resistencia") || message.includes("resistor")) {
    response = "Las resistencias son componentes fundamentales que limitan el flujo de corriente. Se clasifican por su valor en ohmios (Ω) y potencia en vatios (W).\n\nCódigo de colores:\n- Negro: 0\n- Marrón: 1\n- Rojo: 2\n- Naranja: 3\n- Amarillo: 4\n- Verde: 5\n- Azul: 6\n- Violeta: 7\n- Gris: 8\n- Blanco: 9\n\nPara una resistencia de 4 bandas, las primeras dos bandas indican dígitos, la tercera es el multiplicador, y la cuarta la tolerancia.";
    confidence = 0.9;
  }
  else if (message.includes("capacitor") || message.includes("condensador")) {
    response = "Los capacitores almacenan carga eléctrica temporalmente. Se clasifican por su capacitancia (en faradios: F, μF, nF, pF) y voltaje máximo.\n\nTipos principales:\n- Electrolíticos: Alta capacitancia, polarizados\n- Cerámicos: Para altas frecuencias, no polarizados\n- Película: Buena estabilidad, baja tolerancia\n- Tantalio: Compactos, alta capacitancia\n\nUsos: filtrado, acoplamiento/desacoplamiento, temporización, y almacenamiento de energía.";
    confidence = 0.9;
  }
  else if (message.includes("transistor")) {
    response = "Los transistores son dispositivos semiconductores que amplifican o conmutan señales electrónicas. Los tres tipos principales son:\n\n1. Transistor Bipolar (BJT):\n   - NPN y PNP\n   - Terminales: Base, Colector, Emisor\n   - Usos: Amplificación, conmutación\n\n2. Transistor de Efecto de Campo (FET):\n   - JFET: Canal N y Canal P\n   - Terminales: Compuerta, Drenador, Fuente\n   - Menor consumo de energía que los BJT\n\n3. MOSFET:\n   - Enriquecimiento y Agotamiento\n   - Aplicaciones de alta potencia\n   - Muy usados en circuitos integrados";
    confidence = 0.9;
  }
  else if (message.includes("diodo")) {
    response = "Los diodos son componentes electrónicos que permiten el flujo de corriente en una sola dirección. Tipos principales:\n\n1. Diodo rectificador: Para convertir CA a CC\n2. Diodo LED: Emite luz cuando conduce\n3. Diodo Zener: Mantiene voltaje constante en polarización inversa\n4. Diodo Schottky: Baja caída de tensión, conmutación rápida\n5. Fotodiodo: Sensible a la luz\n\nLos diodos tienen un ánodo (+) y un cátodo (-), y la corriente fluye del ánodo al cátodo.";
    confidence = 0.9;
  }
  else if (message.includes("circuito integrado") || message.includes("ic ") || message.includes(" ic") || message.includes("chip")) {
    response = "Los circuitos integrados (ICs) son conjuntos completos de circuitos electrónicos miniaturizados en un chip semiconductor. Se clasifican por:\n\n1. Función:\n   - Analógicos: Amplificadores operacionales, reguladores\n   - Digitales: Microprocesadores, memorias, lógica\n   - Mixtos: Convertidores A/D y D/A\n\n2. Tecnología:\n   - TTL: Lógica Transistor-Transistor\n   - CMOS: Menor consumo de energía\n   - ECL: Alta velocidad\n\n3. Escala de integración:\n   - SSI: Pequeña escala (hasta 10 transistores)\n   - MSI: Media escala (10-100 transistores)\n   - LSI/VLSI/ULSI: Gran escala (miles a millones)";
    confidence = 0.85;
  }
  else if (message.includes("led") && !message.includes("soldado")) {
    response = "Los LEDs (Light Emitting Diodes) son diodos semiconductores que emiten luz cuando se polariza directamente. Características:\n\n1. Color: Depende del material semiconductor (rojo, verde, azul, etc.)\n2. Voltaje típico: 1.8V-3.3V según el color\n3. Polaridad: Terminal más largo es el ánodo (+), el más corto es el cátodo (-)\n4. Siempre requieren una resistencia limitadora en serie\n5. Tipos: Estándar, alta luminosidad, RGB, SMD, COB\n\nLos LEDs son más eficientes que las bombillas incandescentes y tienen mayor vida útil.";
    confidence = 0.9;
  }
  else if (message.includes("pcb") || message.includes("circuito impreso")) {
    response = "Las PCB (Printed Circuit Board) son placas de material no conductor con pistas de cobre que conectan componentes electrónicos. Características:\n\n1. Tipos:\n   - Una cara: Pistas en un solo lado\n   - Doble cara: Pistas en ambos lados\n   - Multicapa: Varias capas de pistas\n\n2. Términos importantes:\n   - Pistas: Conexiones de cobre\n   - Pads: Áreas para soldar componentes\n   - Vías: Conexiones entre capas\n   - Máscara de soldadura: Capa protectora\n   - Serigrafía: Texto y símbolos\n\n3. Fabricación: Fotolitografía, grabado químico, taladrado, metalización de agujeros";
    confidence = 0.85;
  }
  else if (message.includes("multimetro") || message.includes("multímetro") || message.includes("tester")) {
    response = "El multímetro o tester es un instrumento de medición que combina varias funciones. Mediciones principales:\n\n1. Voltaje (V): DC y AC\n   - Conectar en paralelo al circuito\n   - Seleccionar escala mayor al valor esperado\n\n2. Corriente (A): DC y AC\n   - Conectar en serie al circuito\n   - Requiere abrir el circuito\n\n3. Resistencia (Ω):\n   - Medir con circuito desenergizado\n   - No medir resistencias en circuito\n\n4. Otras funciones comunes:\n   - Continuidad: Verifica conexiones\n   - Capacitancia: Mide condensadores\n   - Frecuencia: Señales periódicas\n   - Prueba de diodos/transistores";
    confidence = 0.85;
  }
  else if (message.includes("fuente de alimentación") || message.includes("power supply")) {
    response = "Las fuentes de alimentación convierten la energía eléctrica de una forma a otra. Tipos principales:\n\n1. Lineales:\n   - Transformador, rectificador, filtro, regulador\n   - Menos eficientes pero menos ruido\n\n2. Conmutadas (Switching):\n   - Mayor eficiencia y menor tamaño\n   - Generan más ruido eléctrico\n   - Topologías: Buck, Boost, Buck-Boost, Flyback\n\n3. Parámetros importantes:\n   - Voltaje de salida y tolerancia\n   - Corriente máxima\n   - Regulación de carga y línea\n   - Ripple y ruido\n   - Protecciones: sobrecorriente, sobrevoltaje, temperatura";
    confidence = 0.85;
  }
  else if (request.attachments?.some(att => att.type === 'image')) {
    // Respuesta básica para análisis de imagen
    response = "He analizado la imagen y he detectado varios componentes:\n\n- 3 Resistencias (R1: 10kΩ, R2: 4.7kΩ, R3: 1kΩ)\n- 2 Capacitores (C1: 10μF, C2: 100nF)\n- 1 Transistor NPN (posiblemente 2N2222)\n- 1 Diodo LED\n\nEste parece ser un circuito amplificador básico con filtro RC. Las resistencias R1 y R2 forman un divisor de voltaje para polarizar la base del transistor, mientras que R3 es la resistencia de colector. C1 bloquea DC y C2 filtra ruido de alta frecuencia.";
    confidence = 0.6; // Menor confianza por ser genérica
  }
  else {
    // Respuesta genérica para consultas no identificadas
    response = "Gracias por tu consulta sobre electrónica. Para obtener respuestas más precisas, por favor especifica el componente o concepto que te interesa (resistencias, capacitores, transistores, etc.) o sube una imagen del circuito para análisis.";
    confidence = 0.3; // Baja confianza
  }
  
  return {
    message: response,
    processingTime: Date.now() - startTime,
    confidence: confidence
  };
}

// Función para extraer palabras clave de un texto
function extractKeywords(text: string): string[] {
  const lowerText = text.toLowerCase();
  const stopWords = ['el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'y', 'o', 'pero', 'si', 'no', 'que', 'como', 'para', 'por', 'su', 'mis', 'mi', 'tus', 'tu', 'a', 'ante', 'bajo', 'cabe', 'con', 'contra', 'de', 'desde', 'en', 'entre', 'hacia', 'hasta', 'para', 'por', 'según', 'sin', 'sobre', 'tras'];
  
  // Separar en palabras, eliminar puntuación
  const words = lowerText.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, ' ')
                          .split(/\s+/)
                          .filter(word => word.length > 2 && !stopWords.includes(word));
  
  // Eliminar duplicados
  return [...new Set(words)];
}

// Función para encontrar documentos relevantes basados en palabras clave
function findRelevantDocuments(keywords: string[]): KnowledgeDocument[] {
  if (keywords.length === 0 || knowledgeBase.length === 0) {
    return [];
  }
  
  // Calcular relevancia para cada documento
  const docScores = knowledgeBase
    .filter(doc => doc.status === 'ready' && doc.content)
    .map(doc => {
      // Calcular puntuación basada en coincidencias de palabras clave
      let score = 0;
      const lowerContent = (doc.content || '').toLowerCase();
      const lowerName = doc.name.toLowerCase();
      const lowerDesc = (doc.description || '').toLowerCase();
      const lowerTags = doc.tags.map(tag => tag.toLowerCase());
      
      for (const keyword of keywords) {
        // Puntuación por coincidencia en contenido
        const contentMatches = (lowerContent.match(new RegExp(keyword, 'g')) || []).length;
        score += contentMatches * 1;
        
        // Puntuación extra por coincidencia en nombre, descripción o etiquetas
        if (lowerName.includes(keyword)) score += 10;
        if (lowerDesc.includes(keyword)) score += 5;
        if (lowerTags.some(tag => tag.includes(keyword))) score += 8;
      }
      
      return { doc, score };
    })
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score);
  
  // Devolver los 3 documentos más relevantes
  return docScores.slice(0, 3).map(item => item.doc);
}

// Verificar el estado de la API
export async function checkApiStatus(): Promise<ModelStatusResponse> {
  try {
    // No realizamos una prueba con el modelo real porque falla si la API key no está configurada correctamente
    // En su lugar, verificamos que la variable de entorno esté definida
    const hasApiKey = !!process.env.XAI_API_KEY;
    
    // Si hay API key, asumimos que está disponible pero con advertencia
    if (hasApiKey) {
      return {
        grok: true,
        local: true, // El local siempre está disponible
        hybrid: true, // Si potencialmente hay grok, hybrid también
        message: "Todos los modelos están disponibles. La API se usará cuando sea posible."
      };
    } else {
      // Si no hay API key, solo local disponible
      return {
        grok: false,
        local: true,
        hybrid: false,
        message: "La API de Grok no está disponible (clave API no configurada). Sólo se puede usar el modelo local."
      };
    }
  } catch (error) {
    console.error("Error checking API status:", error);
    return {
      grok: false,
      local: true, // El local siempre está disponible
      hybrid: false, // Si grok no está disponible, hybrid tampoco
      message: "La API de Grok no está disponible. Sólo se puede usar el modelo local."
    };
  }
}