import { 
  Habit, InsertHabit, HabitFrequency, InsertHabitFrequency, 
  HabitCheckIn, InsertHabitCheckIn, User, InsertUser,
  HabitWithFrequency, HabitWithCheckIn, HabitStats
} from "@shared/schema";
import { format, isSameDay, parseISO, subDays, differenceInDays, addDays } from "date-fns";

export interface IStorage {
  // User methods (keeping these for future expansion)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Habit methods
  createHabit(habit: InsertHabit): Promise<Habit>;
  getHabit(id: number): Promise<Habit | undefined>;
  getAllHabits(userId?: number): Promise<Habit[]>;
  updateHabit(id: number, habit: Partial<InsertHabit>): Promise<Habit | undefined>;
  deleteHabit(id: number): Promise<boolean>;
  
  // Habit frequency methods
  createHabitFrequency(frequency: InsertHabitFrequency): Promise<HabitFrequency>;
  getHabitFrequency(habitId: number): Promise<HabitFrequency | undefined>;
  updateHabitFrequency(habitId: number, frequency: Partial<InsertHabitFrequency>): Promise<HabitFrequency | undefined>;
  
  // Habit check-in methods
  createCheckIn(checkIn: InsertHabitCheckIn): Promise<HabitCheckIn>;
  getCheckIn(habitId: number, date: string): Promise<HabitCheckIn | undefined>;
  toggleCheckIn(habitId: number, date: string): Promise<HabitCheckIn>;
  getCheckInsForDateRange(startDate: string, endDate: string): Promise<HabitCheckIn[]>;
  
  // Combined data methods
  getHabitsWithFrequency(): Promise<HabitWithFrequency[]>;
  getHabitsForDate(date: string): Promise<HabitWithCheckIn[]>;
  getHabitStats(days?: number): Promise<HabitStats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private habits: Map<number, Habit>;
  private habitFrequencies: Map<number, HabitFrequency>;
  private habitCheckIns: Map<string, HabitCheckIn>;
  
  private userIdCounter: number;
  private habitIdCounter: number;
  private frequencyIdCounter: number;
  private checkInIdCounter: number;
  
  constructor() {
    this.users = new Map();
    this.habits = new Map();
    this.habitFrequencies = new Map();
    this.habitCheckIns = new Map();
    
    this.userIdCounter = 1;
    this.habitIdCounter = 1;
    this.frequencyIdCounter = 1;
    this.checkInIdCounter = 1;
    
    // Add some sample data for development
    this.addSampleData();
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Habit methods
  async createHabit(insertHabit: InsertHabit): Promise<Habit> {
    const id = this.habitIdCounter++;
    const habit: Habit = { 
      ...insertHabit, 
      id,
      createdAt: new Date()
    };
    this.habits.set(id, habit);
    return habit;
  }
  
  async getHabit(id: number): Promise<Habit | undefined> {
    return this.habits.get(id);
  }
  
  async getAllHabits(userId?: number): Promise<Habit[]> {
    if (userId) {
      return Array.from(this.habits.values()).filter(
        (habit) => habit.userId === userId,
      );
    }
    return Array.from(this.habits.values());
  }
  
  async updateHabit(id: number, habitUpdate: Partial<InsertHabit>): Promise<Habit | undefined> {
    const habit = this.habits.get(id);
    if (!habit) return undefined;
    
    const updatedHabit = { ...habit, ...habitUpdate };
    this.habits.set(id, updatedHabit);
    return updatedHabit;
  }
  
  async deleteHabit(id: number): Promise<boolean> {
    // Delete the habit
    const deleted = this.habits.delete(id);
    
    // Delete associated frequency
    const frequency = await this.getHabitFrequency(id);
    if (frequency) {
      this.habitFrequencies.delete(frequency.id);
    }
    
    // Delete associated check-ins
    Array.from(this.habitCheckIns.values())
      .filter(checkIn => checkIn.habitId === id)
      .forEach(checkIn => {
        this.habitCheckIns.delete(`${checkIn.habitId}-${format(checkIn.date, 'yyyy-MM-dd')}`);
      });
    
    return deleted;
  }
  
  // Habit frequency methods
  async createHabitFrequency(insertFrequency: InsertHabitFrequency): Promise<HabitFrequency> {
    const id = this.frequencyIdCounter++;
    const frequency: HabitFrequency = { ...insertFrequency, id };
    this.habitFrequencies.set(frequency.habitId, frequency);
    return frequency;
  }
  
  async getHabitFrequency(habitId: number): Promise<HabitFrequency | undefined> {
    return Array.from(this.habitFrequencies.values()).find(
      (frequency) => frequency.habitId === habitId,
    );
  }
  
  async updateHabitFrequency(habitId: number, frequencyUpdate: Partial<InsertHabitFrequency>): Promise<HabitFrequency | undefined> {
    const frequency = await this.getHabitFrequency(habitId);
    if (!frequency) return undefined;
    
    const updatedFrequency = { ...frequency, ...frequencyUpdate };
    this.habitFrequencies.set(frequency.id, updatedFrequency);
    return updatedFrequency;
  }
  
  // Habit check-in methods
  async createCheckIn(insertCheckIn: InsertHabitCheckIn): Promise<HabitCheckIn> {
    const id = this.checkInIdCounter++;
    const dateStr = format(insertCheckIn.date, 'yyyy-MM-dd');
    const checkIn: HabitCheckIn = { ...insertCheckIn, id };
    
    // Use composite key of habitId-date for uniqueness
    this.habitCheckIns.set(`${checkIn.habitId}-${dateStr}`, checkIn);
    return checkIn;
  }
  
  async getCheckIn(habitId: number, date: string): Promise<HabitCheckIn | undefined> {
    return this.habitCheckIns.get(`${habitId}-${date}`);
  }
  
  async toggleCheckIn(habitId: number, date: string): Promise<HabitCheckIn> {
    const existingCheckIn = await this.getCheckIn(habitId, date);
    
    if (existingCheckIn) {
      // Toggle the completed status
      const updatedCheckIn: HabitCheckIn = {
        ...existingCheckIn,
        completed: !existingCheckIn.completed
      };
      this.habitCheckIns.set(`${habitId}-${date}`, updatedCheckIn);
      return updatedCheckIn;
    } else {
      // Create new check-in as completed
      return this.createCheckIn({
        habitId,
        date: new Date(date),
        completed: true,
        userId: undefined
      });
    }
  }
  
  async getCheckInsForDateRange(startDate: string, endDate: string): Promise<HabitCheckIn[]> {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    return Array.from(this.habitCheckIns.values()).filter((checkIn) => {
      const checkInDate = new Date(checkIn.date);
      return checkInDate >= start && checkInDate <= end;
    });
  }
  
  // Combined data methods
  async getHabitsWithFrequency(): Promise<HabitWithFrequency[]> {
    const habits = await this.getAllHabits();
    const habitsWithFrequency: HabitWithFrequency[] = [];
    
    for (const habit of habits) {
      const frequency = await this.getHabitFrequency(habit.id);
      if (frequency) {
        habitsWithFrequency.push({
          ...habit,
          frequency
        });
      }
    }
    
    return habitsWithFrequency;
  }
  
  async getHabitsForDate(date: string): Promise<HabitWithCheckIn[]> {
    const habits = await this.getAllHabits();
    const dateObj = new Date(date);
    const day = dateObj.getDay(); // 0 for Sunday, 1 for Monday, etc.
    const dayMap: Record<number, keyof HabitFrequency> = {
      0: 'sunday',
      1: 'monday',
      2: 'tuesday',
      3: 'wednesday',
      4: 'thursday',
      5: 'friday',
      6: 'saturday'
    };
    
    const habitsWithCheckIn: HabitWithCheckIn[] = [];
    
    for (const habit of habits) {
      const frequency = await this.getHabitFrequency(habit.id);
      
      // Skip if no frequency is found or the habit is not scheduled for this day
      if (!frequency || !frequency[dayMap[day]]) continue;
      
      const checkIn = await this.getCheckIn(habit.id, date);
      const streak = await this.calculateStreak(habit.id, date);
      
      habitsWithCheckIn.push({
        ...habit,
        frequency,
        checkIn,
        streak
      });
    }
    
    return habitsWithCheckIn;
  }
  
  async calculateStreak(habitId: number, currentDate: string): Promise<number> {
    let streak = 0;
    let checkDate = new Date(currentDate);
    
    // Check today's completion first
    const todayCheckIn = await this.getCheckIn(habitId, format(checkDate, 'yyyy-MM-dd'));
    let isCompleted = todayCheckIn?.completed || false;
    
    // If today is not completed, start checking from yesterday
    if (!isCompleted) {
      checkDate = subDays(checkDate, 1);
    }
    
    // Keep checking previous days until we find an incomplete one
    while (true) {
      const dateStr = format(checkDate, 'yyyy-MM-dd');
      const checkIn = await this.getCheckIn(habitId, dateStr);
      
      if (checkIn?.completed) {
        streak++;
        checkDate = subDays(checkDate, 1);
      } else {
        break;
      }
    }
    
    return streak;
  }
  
  async getHabitStats(days: number = 30): Promise<HabitStats> {
    const habits = await this.getAllHabits();
    const today = new Date();
    const startDate = subDays(today, days);
    
    // Calculate completion rates and streaks for all habits
    const habitTrends: HabitStats['habitTrends'] = [];
    let bestStreak = 0;
    let totalCheckIns = 0;
    let completedCheckIns = 0;
    
    for (const habit of habits) {
      let habitCompletedCount = 0;
      let habitTotalCount = 0;
      let maxStreak = 0;
      
      // For each day in the range
      for (let d = 0; d < days; d++) {
        const date = format(subDays(today, d), 'yyyy-MM-dd');
        const day = new Date(date).getDay();
        const dayMap: Record<number, keyof HabitFrequency> = {
          0: 'sunday',
          1: 'monday',
          2: 'tuesday',
          3: 'wednesday',
          4: 'thursday',
          5: 'friday',
          6: 'saturday'
        };
        
        // Get the frequency and check if the habit should be tracked on this day
        const frequency = await this.getHabitFrequency(habit.id);
        if (frequency && frequency[dayMap[day]]) {
          habitTotalCount++;
          totalCheckIns++;
          
          // Check if it was completed
          const checkIn = await this.getCheckIn(habit.id, date);
          if (checkIn?.completed) {
            habitCompletedCount++;
            completedCheckIns++;
          }
        }
      }
      
      // Calculate completion rate for this habit
      const completionRate = habitTotalCount > 0 
        ? Math.round((habitCompletedCount / habitTotalCount) * 100) 
        : 0;
      
      // Calculate streak for this habit
      const streak = await this.calculateStreak(habit.id, format(today, 'yyyy-MM-dd'));
      if (streak > bestStreak) {
        bestStreak = streak;
      }
      
      habitTrends.push({
        habitId: habit.id,
        habitName: habit.name,
        category: habit.category,
        completionRate
      });
    }
    
    // Overall completion rate
    const overallCompletionRate = totalCheckIns > 0 
      ? Math.round((completedCheckIns / totalCheckIns) * 100) 
      : 0;
    
    // Calculate current streak across all habits
    const dateToCheck = format(today, 'yyyy-MM-dd');
    const habitsForToday = await this.getHabitsForDate(dateToCheck);
    let currentStreakDays = 0;
    
    // Check how many consecutive days in the past had all habits completed
    let allCompletedTillDate = true;
    for (let d = 0; d <= days; d++) {
      const date = format(subDays(today, d), 'yyyy-MM-dd');
      const habitsForDate = await this.getHabitsForDate(date);
      
      if (habitsForDate.length === 0) continue;
      
      const allCompleted = habitsForDate.every(h => h.checkIn?.completed);
      
      if (allCompleted && allCompletedTillDate) {
        currentStreakDays++;
      } else {
        if (d === 0) {
          // If today is not complete, we'll consider previous days
          allCompletedTillDate = true;
          continue;
        } else {
          break;
        }
      }
    }
    
    return {
      completionRate: overallCompletionRate,
      bestStreak,
      currentStreak: currentStreakDays,
      habitTrends: habitTrends.sort((a, b) => b.completionRate - a.completionRate)
    };
  }

  // Add sample data for development
  private addSampleData() {
    // Create a user
    const user: User = {
      id: this.userIdCounter++,
      username: 'testuser',
      password: 'password'
    };
    this.users.set(user.id, user);

    // Create some habits
    const createSampleHabit = async (
      name: string, 
      description: string, 
      category: string,
      daysOfWeek: Record<string, boolean>
    ) => {
      // Create the habit
      const habit = await this.createHabit({
        name,
        description,
        category,
        userId: user.id,
        reminderTime: null
      });

      // Create the frequency
      await this.createHabitFrequency({
        habitId: habit.id,
        monday: daysOfWeek.monday || false,
        tuesday: daysOfWeek.tuesday || false,
        wednesday: daysOfWeek.wednesday || false,
        thursday: daysOfWeek.thursday || false,
        friday: daysOfWeek.friday || false,
        saturday: daysOfWeek.saturday || false,
        sunday: daysOfWeek.sunday || false
      });

      // Create some check-ins for the past week
      const today = new Date();
      for (let i = 0; i < 10; i++) {
        const date = subDays(today, i);
        const dayName = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][date.getDay()];
        
        // Only create check-ins for days when the habit should be tracked
        if (daysOfWeek[dayName]) {
          // Randomly decide if the habit was completed (with higher chance for completion)
          const completed = Math.random() > 0.3;
          
          await this.createCheckIn({
            habitId: habit.id,
            date,
            completed,
            userId: user.id
          });
        }
      }

      return habit;
    };

    // Create sample habits
    createSampleHabit(
      'Morning Exercise', 
      '30 mins of cardio or strength training', 
      'health',
      { monday: true, tuesday: true, wednesday: true, thursday: true, friday: true, saturday: true, sunday: true }
    );

    createSampleHabit(
      'Read a Book', 
      'Read for at least 30 minutes', 
      'learning',
      { monday: true, tuesday: true, wednesday: true, thursday: true, friday: true, saturday: true, sunday: true }
    );

    createSampleHabit(
      'Daily Planning', 
      'Plan tasks for the day', 
      'productivity',
      { monday: true, tuesday: true, wednesday: true, thursday: true, friday: true, saturday: false, sunday: false }
    );

    createSampleHabit(
      'Meditation', 
      '10 minutes of mindfulness', 
      'health',
      { monday: true, wednesday: true, friday: true, saturday: false, sunday: true, tuesday: false, thursday: false }
    );

    createSampleHabit(
      'Practice Guitar', 
      'Practice for 20 minutes', 
      'learning',
      { monday: false, tuesday: true, wednesday: false, thursday: true, friday: false, saturday: true, sunday: false }
    );
  }
}

// Create and export the storage instance
export const storage = new MemStorage();
