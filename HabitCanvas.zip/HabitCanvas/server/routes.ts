import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { format, subDays, addDays, parseISO } from "date-fns";
import { 
  createHabitSchema,
  insertHabitSchema,
  insertFrequencySchema,
  insertCheckInSchema 
} from "@shared/schema";
import { z } from "zod";
import { spawn, ChildProcess } from "child_process";
import { existsSync } from "fs";
import { WebSocketServer } from "ws";
import * as xai from "./xai";
import { KnowledgeDocument, ChatRequest, ChatResponse } from "../shared/xaiTypes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all habits
  app.get("/api/habits", async (req, res) => {
    try {
      const habits = await storage.getHabitsWithFrequency();
      res.json(habits);
    } catch (error) {
      console.error("Error fetching habits:", error);
      res.status(500).json({ message: "Failed to fetch habits" });
    }
  });

  // Get habits for a specific date
  app.get("/api/habits/date/:date", async (req, res) => {
    try {
      const date = req.params.date;
      // Validate date format
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      const habits = await storage.getHabitsForDate(date);
      res.json(habits);
    } catch (error) {
      console.error("Error fetching habits for date:", error);
      res.status(500).json({ message: "Failed to fetch habits for date" });
    }
  });

  // Get a single habit
  app.get("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }
      
      const habit = await storage.getHabit(id);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      const frequency = await storage.getHabitFrequency(id);
      
      res.json({ ...habit, frequency });
    } catch (error) {
      console.error("Error fetching habit:", error);
      res.status(500).json({ message: "Failed to fetch habit" });
    }
  });

  // Create a new habit with frequency
  app.post("/api/habits", async (req, res) => {
    try {
      const validatedData = createHabitSchema.parse(req.body);
      
      // Create the habit
      const habit = await storage.createHabit({
        name: validatedData.name,
        description: validatedData.description,
        category: validatedData.category,
        reminderTime: validatedData.reminderTime,
        userId: validatedData.userId
      });
      
      // Create the frequency
      const frequency = await storage.createHabitFrequency({
        habitId: habit.id,
        ...validatedData.frequency
      });
      
      res.status(201).json({ ...habit, frequency });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating habit:", error);
      res.status(500).json({ message: "Failed to create habit" });
    }
  });

  // Update a habit
  app.patch("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }
      
      // Validate input data
      const validatedData = createHabitSchema.partial().parse(req.body);
      
      // Update the habit
      const habitData = {
        name: validatedData.name,
        description: validatedData.description,
        category: validatedData.category,
        reminderTime: validatedData.reminderTime,
        userId: validatedData.userId
      };
      
      const habit = await storage.updateHabit(id, habitData);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      // Update frequency if provided
      let frequency = await storage.getHabitFrequency(id);
      if (validatedData.frequency && frequency) {
        frequency = await storage.updateHabitFrequency(id, validatedData.frequency);
      }
      
      res.json({ ...habit, frequency });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating habit:", error);
      res.status(500).json({ message: "Failed to update habit" });
    }
  });

  // Delete a habit
  app.delete("/api/habits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }
      
      const deleted = await storage.deleteHabit(id);
      if (!deleted) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      res.json({ message: "Habit deleted successfully" });
    } catch (error) {
      console.error("Error deleting habit:", error);
      res.status(500).json({ message: "Failed to delete habit" });
    }
  });

  // Toggle habit completion for a specific date
  app.post("/api/habits/:id/toggle/:date", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const date = req.params.date;
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }
      
      // Validate date format
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      const checkIn = await storage.toggleCheckIn(id, date);
      res.json(checkIn);
    } catch (error) {
      console.error("Error toggling habit completion:", error);
      res.status(500).json({ message: "Failed to toggle habit completion" });
    }
  });

  // Get habit statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const days = req.query.days ? parseInt(req.query.days as string) : 30;
      
      if (isNaN(days) || days < 1 || days > 365) {
        return res.status(400).json({ message: "Invalid days parameter. Use a number between 1 and 365" });
      }
      
      const stats = await storage.getHabitStats(days);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching statistics:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Electronic Analyzer API
  
  // Variable to store the analyzer server process
  let analyzerProcess: ChildProcess | null = null;
  
  // Variable para almacenar el modelo de IA actual
  let currentAIModel: string = "local"; // Valor por defecto: local
  
  // Check if the Python server is running
  app.get("/api/electronic-analyzer/status", (req, res) => {
    try {
      // Simple check to see if the process is running
      if (analyzerProcess && !analyzerProcess.killed) {
        fetch("http://localhost:5002/")
          .then(response => {
            if (response.ok) {
              res.status(200).json({ status: "online" });
            } else {
              res.status(503).json({ status: "offline", message: "Service is starting" });
            }
          })
          .catch(error => {
            console.error("Error checking analyzer status:", error);
            res.status(503).json({ status: "offline", message: "Service is unavailable" });
          });
      } else {
        res.status(503).json({ status: "offline", message: "Service is not running" });
      }
    } catch (error) {
      console.error("Error checking electronic analyzer status:", error);
      res.status(500).json({ message: "Failed to check electronic analyzer status" });
    }
  });
  
  // Start the Python server
  app.post("/api/electronic-analyzer/start", (req, res) => {
    try {
      // Don't start if already running
      if (analyzerProcess && !analyzerProcess.killed) {
        return res.status(200).json({ message: "Electronic analyzer is already running" });
      }
      
      // Check if the Python file exists
      if (!existsSync("./web_app.py")) {
        return res.status(500).json({ message: "Electronic analyzer application not found" });
      }
      
      // Start the Python server
      analyzerProcess = spawn("python3", ["web_app.py"]);
      
      // Handle stdout
      analyzerProcess.stdout?.on("data", (data) => {
        console.log(`Electronic Analyzer stdout: ${data}`);
      });
      
      // Handle stderr
      analyzerProcess.stderr?.on("data", (data) => {
        console.error(`Electronic Analyzer stderr: ${data}`);
      });
      
      // Handle process exit
      analyzerProcess.on("close", (code) => {
        console.log(`Electronic Analyzer process exited with code ${code}`);
        analyzerProcess = null;
      });
      
      // Handle process error
      analyzerProcess.on("error", (error) => {
        console.error(`Electronic Analyzer process error: ${error.message}`);
        analyzerProcess = null;
      });
      
      res.status(200).json({ message: "Electronic analyzer server started" });
    } catch (error) {
      console.error("Error starting electronic analyzer:", error);
      res.status(500).json({ message: "Failed to start electronic analyzer" });
    }
  });
  
  // API for xAI integration model selection - simplificado sin necesidad de Python
  app.post("/api/electronic-analyzer/ai-model", async (req, res) => {
    try {
      const { model } = req.body;
      
      if (!model || !["grok", "local", "hybrid"].includes(model)) {
        return res.status(400).json({ message: "Invalid AI model. Valid options are: grok, local, hybrid" });
      }
      
      console.log(`Setting AI model to: ${model}`);
      
      // Verificar si el modo grok es posible (requiere API key)
      if ((model === "grok" || model === "hybrid") && !process.env.XAI_API_KEY) {
        return res.status(400).json({ 
          success: false, 
          message: "No se puede usar el modelo Grok sin una clave API configurada. Cambia a modo 'local' o configura la clave API.",
          available_models: ["local"]
        });
      }
      
      // Si llegamos aquí, podemos usar el modelo solicitado
      // Guardamos la preferencia en memoria para futuras solicitudes
      currentAIModel = model;
      
      return res.json({ 
        success: true, 
        message: `Modelo de IA establecido a: ${model}`, 
        model,
        api_configured: !!process.env.XAI_API_KEY
      });
    } catch (error) {
      console.error("Error setting AI model:", error);
      res.status(500).json({ message: "Failed to set AI model" });
    }
  });
  
  // API for chat with AI about circuits
  app.post("/api/electronic-analyzer/chat", async (req, res) => {
    try {
      const { message, files, model } = req.body;
      
      console.log(`Chat request received. Model: ${model}, Message: ${message?.substring(0, 50)}...`);
      
      // Intentar llamar a la API de xAI directamente si está configurada
      if (process.env.XAI_API_KEY && (model === 'grok' || model === 'hybrid' || !model)) {
        try {
          const baseUrl = "https://api.x.ai/v1";
          const apiKey = process.env.XAI_API_KEY;
          
          // Sistema de prompt específico para componentes electrónicos
          const systemPrompt = `
          Eres un asistente especializado en electrónica y análisis de componentes.
          
          Proporciona respuestas concisas, precisas y técnicamente correctas sobre:
          - Identificación y función de componentes electrónicos (resistencias, capacitores, diodos, etc.)
          - Circuitos electrónicos y su funcionamiento
          - Especificaciones técnicas de componentes
          - Mejores prácticas en diseño electrónico
          
          Usa lenguaje técnico apropiado pero explica los conceptos de forma clara.
          Si no estás seguro de algo, indícalo claramente en lugar de proporcionar información inexacta.
          `;
          
          // Modelo a utilizar
          const aiModel = "grok-2-1212";
          
          // Realizar solicitud a xAI
          const xAIResponse = await fetch(`${baseUrl}/chat/completions`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify({
              model: aiModel,
              messages: [
                { role: "system", content: systemPrompt },
                { role: "user", content: message }
              ],
              max_tokens: 1000
            })
          });
          
          if (xAIResponse.ok) {
            const result = await xAIResponse.json();
            const content = result.choices[0].message.content;
            
            return res.json({
              id: Date.now().toString(),
              content: content,
              timestamp: new Date().toISOString(),
              model: model || "grok",
              source: "xai"
            });
          } else {
            console.error("Error calling xAI API:", await xAIResponse.text());
            throw new Error("Failed to get response from xAI API");
          }
        } catch (xaiError) {
          console.error("Error processing xAI request:", xaiError);
          // Fallback to local responses
        }
      }
      
      // Si xAI falló o estamos en modo local, usar respuestas locales
      let response = "No pude entender tu consulta. ¿Podrías ser más específico sobre qué componente electrónico te interesa?";
      
      // Respuestas basadas en palabras clave para modo local o fallback
      if (message) {
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes("resistencia") || lowerMessage.includes("resistor")) {
          response = "Las resistencias son componentes pasivos que limitan el flujo de corriente eléctrica. Se identifican por sus bandas de colores que indican su valor en ohmios. Son uno de los componentes más comunes en circuitos electrónicos.";
        } else if (lowerMessage.includes("capacitor") || lowerMessage.includes("condensador")) {
          response = "Los capacitores almacenan energía eléctrica en un campo eléctrico. Existen varios tipos: cerámicos, electrolíticos, de tantalio, etc. Su capacidad se mide en faradios (F) y son usados para filtrado, acoplamiento y desacoplamiento.";
        } else if (lowerMessage.includes("transistor")) {
          response = "Los transistores son semiconductores que amplifican o conmutan señales electrónicas. Los tipos principales son BJT (Bipolar Junction Transistor) y MOSFET (Metal-Oxide-Semiconductor Field-Effect Transistor).";
        } else if (lowerMessage.includes("diodo")) {
          response = "Los diodos permiten el flujo de corriente en una sola dirección. Se usan para rectificación, protección contra polaridad inversa y como indicadores (LEDs).";
        } else if ((lowerMessage.includes("circuito") && lowerMessage.includes("integrado")) || lowerMessage.includes("ic") || lowerMessage.includes("chip")) {
          response = "Los circuitos integrados (ICs) contienen múltiples componentes en un solo chip semiconductor. Pueden ser desde simples puertas lógicas hasta microprocesadores complejos.";
        } else if (lowerMessage.includes("inductor") || lowerMessage.includes("bobina")) {
          response = "Los inductores o bobinas almacenan energía en forma de campo magnético. Son utilizados en filtros, osciladores y circuitos de potencia. Su unidad es el Henry (H).";
        } else if (lowerMessage.includes("transformador")) {
          response = "Los transformadores transfieren energía eléctrica de un circuito a otro mediante inducción electromagnética. Se utilizan para cambiar niveles de voltaje, aislamiento galvánico y adaptación de impedancias.";
        } else if (lowerMessage.includes("relay") || lowerMessage.includes("relé")) {
          response = "Los relés son interruptores operados eléctricamente. Permiten que una señal de baja potencia controle un circuito de alta potencia, proporcionando aislamiento entre ambos.";
        } else if (lowerMessage.includes("led")) {
          response = "Los LEDs (Light Emitting Diodes) son componentes que emiten luz cuando una corriente eléctrica pasa a través de ellos. Son muy eficientes energéticamente y disponibles en diversos colores.";
        } else if (lowerMessage.includes("modelo") || lowerMessage.includes("ai") || lowerMessage.includes("ia")) {
          response = "Existen tres modos de análisis disponibles: 'grok' utiliza la API xAI con modelos Grok para análisis avanzado, 'local' utiliza algoritmos básicos sin conectarse a servicios externos, y 'hybrid' combina ambos enfoques.";
        }
      }
      
      return res.json({
        id: Date.now().toString(),
        content: response,
        timestamp: new Date().toISOString(),
        model: model || "local",
        source: "local"
      });
    } catch (error) {
      console.error("Error in chat API:", error);
      res.status(500).json({ 
        message: "Failed to process chat message",
        content: "Lo siento, ha ocurrido un error al procesar tu consulta. Por favor intenta de nuevo más tarde."
      });
    }
  });
  
  // API to upload files for analysis
  app.post("/api/electronic-analyzer/upload", async (req, res) => {
    try {
      console.log("File upload request received");
      // In a real implementation, we would handle file uploads and save them for processing
      res.status(201).json({
        id: Date.now().toString(),
        message: "Archivo recibido correctamente para análisis",
        status: "pending"
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });
  
  // Proxy requests to the Python server
  app.all("/electronic-analyzer*", (req, res) => {
    // Check if the server is running
    if (!analyzerProcess || analyzerProcess.killed) {
      return res.status(503).json({ message: "Electronic analyzer server is not running" });
    }
    
    // Forward request to the Python server on port 5002
    const target = `http://localhost:5002${req.url.replace("/electronic-analyzer", "")}`;
    
    // Forward the request
    fetch(target, {
      method: req.method,
      headers: req.headers as any,
      body: req.method !== "GET" && req.method !== "HEAD" ? req.body : undefined,
    })
      .then(async response => {
        // Set status code
        res.status(response.status);
        
        // Set headers
        for (const [key, value] of response.headers.entries()) {
          res.setHeader(key, value);
        }
        
        // Forward response body
        const buffer = await response.arrayBuffer();
        res.send(Buffer.from(buffer));
      })
      .catch(error => {
        console.error("Error proxying request to electronic analyzer:", error);
        res.status(500).json({ message: "Failed to proxy request to electronic analyzer" });
      });
  });

  // Create HTTP server
  // Nuevas rutas para la integración con xAI
  
  // Obtener estado del modelo de IA
  app.get("/api/xai/status", async (req, res) => {
    try {
      const status = await xai.checkApiStatus();
      res.json(status);
    } catch (error) {
      console.error("Error checking xAI status:", error);
      res.status(500).json({ 
        message: "Failed to check xAI status",
        grok: false,
        local: true,
        hybrid: false
      });
    }
  });
  
  // API para consultas de chat
  app.post("/api/xai/chat", async (req, res) => {
    try {
      const chatRequest: ChatRequest = req.body;
      
      if (!chatRequest.message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      if (!chatRequest.model || !["grok", "local", "hybrid"].includes(chatRequest.model)) {
        chatRequest.model = "hybrid"; // Valor predeterminado
      }
      
      console.log(`Chat request: model=${chatRequest.model}, message="${chatRequest.message.substring(0, 50)}..."${chatRequest.attachments ? `, with ${chatRequest.attachments.length} attachments` : ""}`);
      
      const response = await xai.processChat(chatRequest);
      res.json(response);
    } catch (error) {
      console.error("Error processing chat request:", error);
      res.status(500).json({ 
        message: "Lo siento, ocurrió un error al procesar tu consulta. Por favor intenta nuevamente más tarde.",
        processingTime: 0,
        confidence: 0
      });
    }
  });
  
  // Obtener documentos de la base de conocimiento
  app.get("/api/xai/knowledge", (req, res) => {
    try {
      const documents = xai.getKnowledgeDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Error getting knowledge documents:", error);
      res.status(500).json({ message: "Failed to get knowledge documents" });
    }
  });
  
  // Agregar documento a la base de conocimiento
  app.post("/api/xai/knowledge", async (req, res) => {
    try {
      const { document, fileData } = req.body;
      
      if (!document || !document.name || !document.type) {
        return res.status(400).json({ message: "Invalid document data" });
      }
      
      // Asignar ID único si no tiene
      if (!document.id) {
        document.id = Date.now().toString() + Math.random().toString(36).substring(2, 9);
      }
      
      // Asignar fecha si no tiene
      if (!document.addedAt) {
        document.addedAt = new Date();
      }
      
      // Asignar estado inicial
      document.status = 'processing';
      
      // Asegurarse de que tenga un array de tags
      if (!document.tags || !Array.isArray(document.tags)) {
        document.tags = [];
      }
      
      const result = await xai.addKnowledgeDocument(document, fileData);
      res.status(201).json({ document: result, message: "Document added successfully" });
    } catch (error) {
      console.error("Error adding knowledge document:", error);
      res.status(500).json({ message: "Failed to add knowledge document" });
    }
  });
  
  // Eliminar documento de la base de conocimiento
  app.delete("/api/xai/knowledge/:id", (req, res) => {
    try {
      const { id } = req.params;
      
      if (!id) {
        return res.status(400).json({ message: "Document ID is required" });
      }
      
      const removed = xai.removeKnowledgeDocument(id);
      
      if (removed) {
        res.json({ message: "Document removed successfully" });
      } else {
        res.status(404).json({ message: "Document not found" });
      }
    } catch (error) {
      console.error("Error removing knowledge document:", error);
      res.status(500).json({ message: "Failed to remove knowledge document" });
    }
  });

  // Configurar WebSocket server para comunicación en tiempo real
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Manejar conexiones de WebSocket
  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');
    
    // Enviar un mensaje de bienvenida
    ws.send(JSON.stringify({
      type: 'system',
      message: 'Conexión establecida con el servidor de análisis electrónico',
      timestamp: new Date().toISOString()
    }));
    
    // Manejar mensajes recibidos
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Manejar diferentes tipos de mensajes
        if (data.type === 'chat') {
          // Procesar mensaje de chat
          const chatRequest: ChatRequest = {
            message: data.message,
            model: data.model || 'hybrid',
            attachments: data.attachments,
            documentIds: data.documentIds
          };
          
          console.log(`WebSocket chat request: model=${chatRequest.model}, message="${chatRequest.message.substring(0, 50)}..."${chatRequest.attachments ? `, with ${chatRequest.attachments.length} attachments` : ""}`);
          
          // Enviar notificación de "escribiendo"
          ws.send(JSON.stringify({
            type: 'typing',
            status: true,
            timestamp: new Date().toISOString()
          }));
          
          // Procesar el chat
          const response = await xai.processChat(chatRequest);
          
          // Enviar respuesta
          ws.send(JSON.stringify({
            type: 'chat',
            message: response.message,
            attachments: response.attachments,
            processingTime: response.processingTime,
            usedDocuments: response.usedDocuments,
            confidence: response.confidence,
            timestamp: new Date().toISOString()
          }));
          
          // Detener notificación de "escribiendo"
          ws.send(JSON.stringify({
            type: 'typing',
            status: false,
            timestamp: new Date().toISOString()
          }));
        } 
        else if (data.type === 'status') {
          // Enviar estado de los modelos
          const status = await xai.checkApiStatus();
          ws.send(JSON.stringify({
            type: 'status',
            ...status,
            timestamp: new Date().toISOString()
          }));
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        
        // Enviar mensaje de error
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Error al procesar la solicitud',
          timestamp: new Date().toISOString()
        }));
      }
    });
    
    // Manejar cierre de conexión
    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });
  
  return httpServer;
}
