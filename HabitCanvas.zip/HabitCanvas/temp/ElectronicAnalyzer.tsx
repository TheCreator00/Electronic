import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect, useRef } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { CustomBadge } from "@/components/ui/custom-badge";

// Tipo para los mensajes del chat
interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
  attachments?: {
    type: 'image' | 'file';
    url: string;
    name: string;
  }[];
}

// Tipo para los documentos de conocimiento
interface KnowledgeDocument {
  id: string;
  name: string;
  type: 'pdf' | 'txt' | 'doc' | 'image';
  path: string;
  addedAt: Date;
  description?: string;
  tags: string[];
  status: 'processing' | 'ready' | 'error';
}

export default function ElectronicAnalyzer() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [serverStatus, setServerStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const [activeTab, setActiveTab] = useState("info");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [selectedAiModel, setSelectedAiModel] = useState("grok");
  const [isAiResponding, setIsAiResponding] = useState(false);
  const [showKnowledgeDialog, setShowKnowledgeDialog] = useState(false);
  const [knowledgeDocuments, setKnowledgeDocuments] = useState<KnowledgeDocument[]>([]);
  const [isUploadingDocument, setIsUploadingDocument] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [documentDescription, setDocumentDescription] = useState("");
  const [documentTags, setDocumentTags] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const knowledgeFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Check if the Python backend is running
    const checkServerStatus = async () => {
      try {
        const response = await fetch('/api/electronic-analyzer/status');
        if (response.ok) {
          setServerStatus('online');
        } else {
          setServerStatus('offline');
        }
      } catch (error) {
        console.error('Error checking analyzer server status:', error);
        setServerStatus('offline');
      }
    };

    checkServerStatus();
  }, []);

  // Iniciar el servicio de análisis
  const startServer = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/electronic-analyzer/start', {
        method: 'POST'
      });
      
      if (response.ok) {
        toast({
          title: "Servicio iniciado",
          description: "El analizador de componentes electrónicos está iniciando...",
        });
        
        // Poll for server status
        const checkInterval = setInterval(async () => {
          try {
            const statusRes = await fetch('/api/electronic-analyzer/status');
            if (statusRes.ok) {
              clearInterval(checkInterval);
              setServerStatus('online');
              setIsLoading(false);
              
              // Añadir mensaje de bienvenida al chat
              const welcomeMessage: ChatMessage = {
                id: Date.now().toString(),
                sender: 'ai',
                content: "¡Hola! Soy tu asistente de análisis de componentes electrónicos. Puedes subir una imagen o documento para analizar, o preguntarme sobre circuitos electrónicos.",
                timestamp: new Date()
              };
              setMessages([welcomeMessage]);
            }
          } catch (error) {
            // Continue polling
          }
        }, 2000);
        
        // Stop polling after 30 seconds if server doesn't come online
        setTimeout(() => {
          clearInterval(checkInterval);
          if (serverStatus !== 'online') {
            setServerStatus('offline');
            setIsLoading(false);
            toast({
              title: "Error",
              description: "No se pudo iniciar el analizador de componentes electrónicos",
              variant: "destructive"
            });
          }
        }, 30000);
      } else {
        throw new Error('Failed to start server');
      }
    } catch (error) {
      console.error('Error starting analyzer server:', error);
      toast({
        title: "Error",
        description: "No se pudo iniciar el analizador de componentes electrónicos",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };

  // Abrir analizador en una nueva pestaña
  const openAnalyzer = () => {
    window.open('/electronic-analyzer', '_blank');
  };

  // Hacer scroll al final de los mensajes cuando hay nuevos
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Enviar mensaje al chat
  const sendMessage = async () => {
    if (!inputMessage.trim() && (!selectedFiles || selectedFiles.length === 0)) return;
    
    // Crear un nuevo mensaje
    const newUserMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      content: inputMessage,
      timestamp: new Date()
    };
    
    // Si hay archivos adjuntos, procesarlos
    if (selectedFiles && selectedFiles.length > 0) {
      newUserMessage.attachments = [];
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        const fileType = file.type.startsWith('image/') ? 'image' : 'file';
        
        // Crear URL temporal para el archivo
        const fileUrl = URL.createObjectURL(file);
        newUserMessage.attachments.push({
          type: fileType,
          url: fileUrl,
          name: file.name
        });
        
        // Si es una imagen, procesarla con el analizador
        if (fileType === 'image') {
          // Aquí iría el código para enviar la imagen al analizador
          // Por ahora, solo simulamos una solicitud
          try {
            const formData = new FormData();
            formData.append('file', file);
            
            // Subir archivo para análisis (esto se implementaría completamente en una versión real)
            fetch('/api/electronic-analyzer/upload', {
              method: 'POST',
              body: formData
            });
          } catch (error) {
            console.error('Error al subir imagen para análisis:', error);
          }
        }
      }
    }
    
    // Añadir el mensaje del usuario al chat
    setMessages(prevMessages => [...prevMessages, newUserMessage]);
    setInputMessage('');
    setSelectedFiles(null);
    
    // Obtener respuesta de la IA
    setIsAiResponding(true);
    
    try {
      // Comunicarse con la API del analizador
      const response = await fetch('/api/electronic-analyzer/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: inputMessage,
          files: selectedFiles ? Array.from(selectedFiles).map(file => file.name) : [],
          model: selectedAiModel
        })
      });
      
      if (response.ok) {
        const responseData = await response.json();
        const aiResponse: ChatMessage = {
          id: responseData.id || Date.now().toString(),
          sender: 'ai',
          content: responseData.content,
          timestamp: new Date(responseData.timestamp) || new Date()
        };
        setMessages(prevMessages => [...prevMessages, aiResponse]);
      } else {
        // Si hay un error en la API, usamos respuestas locales
        const aiResponse: ChatMessage = {
          id: Date.now().toString(),
          sender: 'ai',
          content: getAiResponse(inputMessage, selectedAiModel),
          timestamp: new Date()
        };
        setMessages(prevMessages => [...prevMessages, aiResponse]);
      }
    } catch (error) {
      console.error('Error obteniendo respuesta:', error);
      // Fallar elegantemente con respuestas locales
      const aiResponse: ChatMessage = {
        id: Date.now().toString(),
        sender: 'ai',
        content: getAiResponse(inputMessage, selectedAiModel),
        timestamp: new Date()
      };
      setMessages(prevMessages => [...prevMessages, aiResponse]);
    } finally {
      setIsAiResponding(false);
    }
  };

  // Abrir selector de archivos
  const openFileSelector = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  // Manejar cambio de archivos seleccionados
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedFiles(e.target.files);
  };

  // Obtener respuesta simulada de la IA según el modelo seleccionado
  const getAiResponse = (message: string, model: string): string => {
    if (!message.trim()) {
      if (selectedFiles && selectedFiles.length > 0) {
        for (let i = 0; i < selectedFiles.length; i++) {
          const file = selectedFiles[i];
          if (file.type.startsWith('image/')) {
            return `He recibido tu imagen "${file.name}". Analizaré este circuito. Parece contener varios componentes electrónicos. Para un análisis completo, te recomendaría usar la función de análisis completo del analizador. ¿Quieres que identifique algún componente específico de esta imagen?`;
          } else {
            return `He recibido tu archivo "${file.name}". Para analizarlo completamente, te recomendaría usar la función de análisis completo del analizador. ¿Hay alguna parte específica del circuito sobre la que tengas dudas?`;
          }
        }
      }
      return "No entiendo bien tu consulta. ¿Podrías proporcionar más detalles o subir una imagen del circuito?";
    }

    if (message.toLowerCase().includes("resistencia") || message.toLowerCase().includes("resistor")) {
      return "Las resistencias son componentes pasivos que limitan el flujo de corriente eléctrica. Se identifican por sus bandas de colores que indican su valor en ohmios. En los circuitos, se usan para dividir voltajes, limitar corrientes y establecer puntos de operación para componentes activos.";
    } else if (message.toLowerCase().includes("capacitor") || message.toLowerCase().includes("condensador")) {
      return "Los capacitores almacenan energía eléctrica en un campo eléctrico. Existen varios tipos como cerámicos, electrolíticos, de tantalio, etc. Se utilizan para filtrar señales, acoplar/desacoplar etapas, y en circuitos temporizadores.";
    } else if (message.toLowerCase().includes("transistor")) {
      return "Los transistores son semiconductores que amplifican o conmutan señales electrónicas. Los tipos principales son BJT (Bipolar Junction Transistor) y MOSFET (Metal-Oxide-Semiconductor Field-Effect Transistor). Se utilizan en circuitos amplificadores, conmutadores, osciladores y más.";
    } else if (message.toLowerCase().includes("diodo")) {
      return "Los diodos permiten el flujo de corriente en una sola dirección. Los hay de diversos tipos: rectificadores, zener, LED, fotodiodos, etc. Se usan en rectificación, protección contra polaridad inversa, emisión de luz (LEDs) y muchas otras aplicaciones.";
    } else if (message.toLowerCase().includes("integrado") || message.toLowerCase().includes("circuito integrado") || message.toLowerCase().includes("ic")) {
      return "Los circuitos integrados contienen múltiples componentes en un solo chip. Pueden ser analógicos, digitales o mixtos. Ejemplos incluyen amplificadores operacionales, microcontroladores, chips de memoria, etc. Cada IC tiene una función específica según su diseño.";
    } else {
      const responses = [
        "Para analizar mejor este circuito, ¿podrías subir una imagen clara del mismo? Eso me permitiría identificar los componentes y su interconexión.",
        "Interesante consulta. Para dar una respuesta más precisa, necesitaría más detalles sobre el circuito o una imagen del mismo.",
        "Los circuitos electrónicos pueden ser complejos. Si tienes una imagen o esquema, podría ayudarte a entender mejor su funcionamiento.",
        "¿Tienes alguna imagen del circuito? Eso facilitaría mucho el análisis y podría darte una respuesta más detallada."
      ];
      return responses[Math.floor(Math.random() * responses.length)];
    }
  };

  // Renderizar mensaje individual
  const renderMessage = (message: ChatMessage) => {
    return (
      <div 
        key={message.id} 
        className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
      >
        <div 
          className={`max-w-[80%] rounded-lg p-3 ${
            message.sender === 'user' 
              ? 'bg-primary text-primary-foreground' 
              : 'bg-muted'
          }`}
        >
          {message.attachments && message.attachments.length > 0 && (
            <div className="mb-2 space-y-2">
              {message.attachments.map((attachment, index) => (
                <div key={index}>
                  {attachment.type === 'image' ? (
                    <div>
                      <img 
                        src={attachment.url} 
                        alt={attachment.name}
                        className="max-w-full rounded-md mb-1" 
                      />
                      <p className="text-xs opacity-70">{attachment.name}</p>
                    </div>
                  ) : (
                    <div className="flex items-center p-2 bg-gray-700 rounded-md">
                      <svg className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      <span>{attachment.name}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
          {message.content && <p>{message.content}</p>}
          <div className="text-xs opacity-50 mt-1 text-right">
            {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-8">Analizador de Componentes Electrónicos</h1>
      
      <Tabs defaultValue="info" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="info">Información</TabsTrigger>
          <TabsTrigger value="chat" disabled={serverStatus !== 'online'}>
            Chat Asistente
          </TabsTrigger>
          <TabsTrigger value="knowledge" disabled={serverStatus !== 'online'}>
            Base de Conocimiento
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="info">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Acerca del Analizador</CardTitle>
                <CardDescription>
                  Herramienta avanzada para el análisis de componentes electrónicos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  El analizador de componentes electrónicos utiliza tecnologías avanzadas para identificar y 
                  analizar componentes en imágenes y documentos electrónicos:
                </p>
                <ul className="list-disc pl-5 space-y-2 mb-4">
                  <li>Visión por computadora (OpenCV) para análisis de formas y colores</li>
                  <li>Inteligencia artificial avanzada con xAI (Grok) para mejores resultados</li>
                  <li>Modelos de TensorFlow y ONNX para procesamiento local</li>
                  <li>Identificación precisa de componentes electrónicos</li>
                  <li>Análisis de conexiones entre componentes</li>
                  <li>Generación de informes detallados</li>
                  <li>Visualización de resultados con gráficos interactivos</li>
                </ul>
                <div className="p-3 bg-blue-50 dark:bg-blue-900/30 rounded-lg border border-blue-200 dark:border-blue-800 mt-4">
                  <p className="text-sm text-blue-700 dark:text-blue-300 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Ahora con mejoras de análisis potenciadas por <span className="font-bold">xAI (Grok)</span> para una detección de componentes más inteligente y detallada.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Estado del Servicio</CardTitle>
                <CardDescription>
                  Control del servicio de análisis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center mb-4">
                  <div className="mr-2 h-3 w-3 rounded-full bg-gray-300">
                    {serverStatus === 'online' && <div className="h-3 w-3 rounded-full bg-green-500 animate-pulse"></div>}
                    {serverStatus === 'offline' && <div className="h-3 w-3 rounded-full bg-red-500"></div>}
                    {serverStatus === 'checking' && <div className="h-3 w-3 rounded-full bg-yellow-500 animate-pulse"></div>}
                  </div>
                  <span>
                    {serverStatus === 'online' && 'Servicio activo'}
                    {serverStatus === 'offline' && 'Servicio inactivo'}
                    {serverStatus === 'checking' && 'Verificando estado...'}
                  </span>
                </div>
                
                <div className="space-y-4">
                  {serverStatus === 'offline' && (
                    <Button 
                      className="w-full"
                      disabled={isLoading}
                      onClick={startServer}
                    >
                      {isLoading ? 'Iniciando servicio...' : 'Iniciar servicio'}
                    </Button>
                  )}
                  
                  {serverStatus === 'online' && (
                    <>
                      <Button 
                        className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                        onClick={openAnalyzer}
                      >
                        Abrir Analizador
                      </Button>
                      <Button
                        className="w-full mt-2"
                        variant="outline"
                        onClick={() => setActiveTab("chat")}
                      >
                        Usar Asistente de Chat
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Información adicional */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Cómo utilizar</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Inicie el servicio si no está activo</li>
                  <li>Haga clic en "Abrir Analizador" para acceder a la aplicación completa o use el Chat Asistente</li>
                  <li>Cargue una imagen o documento con circuitos electrónicos</li>
                  <li>Inicie el análisis y revise los resultados</li>
                  <li>Consulte con el asistente de chat si tiene preguntas específicas</li>
                  <li>Exporte los resultados en el formato que necesite</li>
                </ol>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="chat">
          <Card className="h-[75vh] flex flex-col">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Asistente de Análisis</CardTitle>
                  <CardDescription>
                    Consulta sobre componentes y circuitos electrónicos
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Select 
                    value={selectedAiModel} 
                    onValueChange={(value) => {
                      setSelectedAiModel(value);
                      // Enviar la selección al servidor
                      fetch('/api/electronic-analyzer/ai-model', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ model: value })
                      })
                      .then(response => {
                        if (response.ok) {
                          toast({
                            title: "Modelo de IA cambiado",
                            description: `Ahora utilizando: ${value === 'grok' ? 'xAI (Grok)' : value === 'local' ? 'Modelo Local' : 'Modo Híbrido'}`,
                          });
                        }
                      })
                      .catch(error => console.error('Error al cambiar modelo:', error));
                    }}
                  >
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Seleccionar modelo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="grok">xAI (Grok)</SelectItem>
                      <SelectItem value="local">Modelo Local</SelectItem>
                      <SelectItem value="hybrid">Modo Híbrido</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <Separator />
            
            <CardContent className="flex-grow overflow-y-auto pt-4">
              <div className="space-y-4 pb-4">
                {messages.length === 0 ? (
                  <div className="text-center text-muted-foreground p-8">
                    <div className="flex justify-center mb-4">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                      </svg>
                    </div>
                    <h3 className="font-medium text-lg">Sin mensajes aún</h3>
                    <p className="mt-1">Comienza una conversación con el asistente sobre componentes electrónicos.</p>
                  </div>
                ) : (
                  messages.map(message => renderMessage(message))
                )}
                
                {isAiResponding && (
                  <div className="flex justify-start mb-4">
                    <div className="bg-muted p-3 rounded-lg">
                      <div className="flex space-x-2">
                        <div className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                        <div className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></div>
                        <div className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>
            </CardContent>
            
            <div className="p-4 border-t">
              {selectedFiles && selectedFiles.length > 0 && (
                <div className="mb-2 p-2 bg-muted rounded-md">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                      </svg>
                      <span className="text-sm truncate max-w-[200px]">
                        {selectedFiles.length === 1 
                          ? selectedFiles[0].name 
                          : `${selectedFiles.length} archivos seleccionados`
                        }
                      </span>
                    </div>
                    <button 
                      className="text-gray-500 hover:text-gray-700"
                      onClick={() => setSelectedFiles(null)}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                </div>
              )}
              
              <div className="flex items-center space-x-2">
                <Button 
                  size="icon" 
                  variant="outline" 
                  onClick={openFileSelector}
                  title="Adjuntar archivo"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                  </svg>
                </Button>
                <input
                  type="file"
                  className="hidden"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  multiple
                  accept="image/*,.pdf,.doc,.docx"
                />
                
                <Textarea
                  placeholder="Escribe tu mensaje o pregunta sobre componentes electrónicos..."
                  className="flex-grow"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                  rows={1}
                />
                
                <Button 
                  size="icon" 
                  onClick={sendMessage}
                  disabled={isAiResponding}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="knowledge">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="h-[75vh] flex flex-col">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Base de Conocimiento</CardTitle>
                      <CardDescription>
                        Documentos para mejorar el análisis de componentes
                      </CardDescription>
                    </div>
                    <Button 
                      className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                      onClick={() => setShowKnowledgeDialog(true)}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                      </svg>
                      Añadir Documento
                    </Button>
                  </div>
                </CardHeader>
                <Separator />
                
                <CardContent className="flex-grow overflow-y-auto pt-4">
                  {knowledgeDocuments.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-8">
                      <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                      </div>
                      <h3 className="text-xl font-medium mb-2">Sin documentos</h3>
                      <p className="text-muted-foreground max-w-md mb-6">
                        Añade documentos técnicos, manuales o imágenes para mejorar el análisis y las respuestas
                        del sistema. La IA usará estos documentos como referencia para responder a tus consultas.
                      </p>
                      <Button
                        onClick={() => setShowKnowledgeDialog(true)}
                        className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Añadir Primer Documento
                      </Button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {knowledgeDocuments.map(doc => (
                        <div key={doc.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow flex flex-col h-full">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center">
                              {doc.type === 'pdf' && (
                                <div className="w-8 h-8 rounded bg-red-100 flex items-center justify-center mr-3">
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                  </svg>
                                </div>
                              )}
                              {doc.type === 'txt' && (
                                <div className="w-8 h-8 rounded bg-blue-100 flex items-center justify-center mr-3">
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                  </svg>
                                </div>
                              )}
                              {doc.type === 'doc' && (
                                <div className="w-8 h-8 rounded bg-indigo-100 flex items-center justify-center mr-3">
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                  </svg>
                                </div>
                              )}
                              {doc.type === 'image' && (
                                <div className="w-8 h-8 rounded bg-purple-100 flex items-center justify-center mr-3">
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                  </svg>
                                </div>
                              )}
                              <div>
                                <h3 className="font-medium">{doc.name}</h3>
                                <p className="text-xs text-muted-foreground">
                                  {new Date(doc.addedAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <CustomBadge variant={doc.status === 'ready' ? 'success' : doc.status === 'processing' ? 'outline' : 'destructive'}>
                              {doc.status === 'ready' ? 'Listo' : doc.status === 'processing' ? 'Procesando' : 'Error'}
                            </CustomBadge>
                          </div>
                          
                          {doc.description && (
                            <p className="text-sm mb-3 text-muted-foreground flex-grow">{doc.description}</p>
                          )}
                          
                          <div className="flex flex-wrap gap-1 mb-3">
                            {doc.tags.map((tag, index) => (
                              <CustomBadge key={index} variant="secondary" className="text-xs">{tag}</CustomBadge>
                            ))}
                          </div>
                          
                          <div className="flex justify-end mt-auto">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                                  </svg>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>Ver detalles</DropdownMenuItem>
                                <DropdownMenuItem>Descargar</DropdownMenuItem>
                                <DropdownMenuItem className="text-red-600">Eliminar</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card className="h-[75vh] flex flex-col">
                <CardHeader>
                  <CardTitle>Resumen de Conocimiento</CardTitle>
                  <CardDescription>
                    Información extraída de tus documentos
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow overflow-y-auto space-y-6">
                  {knowledgeDocuments.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>Aún no hay documentos para extraer información.</p>
                      <p className="mt-2">Añade documentos para empezar a construir la base de conocimiento.</p>
                    </div>
                  ) : (
                    <>
                      <div>
                        <h3 className="text-lg font-medium mb-2">Conceptos clave</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span>Componentes</span>
                            <span className="font-medium">32 conceptos</span>
                          </div>
                          <Progress value={65} />
                        </div>
                        <div className="space-y-2 mt-4">
                          <div className="flex justify-between">
                            <span>Circuitos</span>
                            <span className="font-medium">14 conceptos</span>
                          </div>
                          <Progress value={35} />
                        </div>
                        <div className="space-y-2 mt-4">
                          <div className="flex justify-between">
                            <span>Mediciones</span>
                            <span className="font-medium">8 conceptos</span>
                          </div>
                          <Progress value={20} />
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h3 className="text-lg font-medium mb-2">Información de componentes</h3>
                        <ScrollArea className="h-[120px]">
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span>Resistencia</span>
                              <CustomBadge variant="info">Básico</CustomBadge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span>Capacitor</span>
                              <CustomBadge variant="info">Básico</CustomBadge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span>Diodo</span>
                              <CustomBadge variant="info">Básico</CustomBadge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span>Transistor</span>
                              <CustomBadge variant="warning">Intermedio</CustomBadge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span>Circuito Integrado</span>
                              <CustomBadge variant="secondary">Avanzado</CustomBadge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span>Inductor</span>
                              <CustomBadge variant="info">Básico</CustomBadge>
                            </div>
                          </div>
                        </ScrollArea>
                      </div>
                    </>
                  )}
                </CardContent>
                <CardFooter className="border-t">
                  <Button variant="outline" className="w-full" onClick={() => setActiveTab("chat")} disabled={knowledgeDocuments.length === 0}>
                    Preguntar sobre los documentos
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>

    <Dialog open={showKnowledgeDialog} onOpenChange={setShowKnowledgeDialog}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Añadir documento a la base de conocimiento</DialogTitle>
          <DialogDescription>
            Sube documentos técnicos, manuales o imágenes para mejorar el análisis y las respuestas.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {!selectedFiles || selectedFiles.length === 0 ? (
            <div 
              className="border-2 border-dashed rounded-lg p-10 text-center cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => knowledgeFileInputRef.current?.click()}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mx-auto mb-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
              <div className="text-muted-foreground">
                <p className="mb-1 font-medium">Haz clic para seleccionar o arrastra archivos aquí</p>
                <p className="text-sm">Archivos PDF, TXT, DOC(X) o imágenes</p>
              </div>
              <input
                type="file"
                className="hidden"
                ref={knowledgeFileInputRef}
                onChange={handleFileChange}
                accept=".pdf,.txt,.doc,.docx,image/*"
                multiple
              />
            </div>
          ) : (
            <div className="border rounded-lg p-4">
              <div className="flex justify-between items-center mb-3">
                <h4 className="font-medium">Archivos seleccionados</h4>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setSelectedFiles(null)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </Button>
              </div>
              
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {selectedFiles && Array.from(selectedFiles).map((file, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      <span>{file.name}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {Math.round(file.size / 1024)} KB
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="space-y-3">
            <div>
              <label htmlFor="description" className="text-sm font-medium">
                Descripción (opcional)
              </label>
              <Textarea
                id="description"
                placeholder="Añade una descripción para este documento"
                className="mt-1"
                value={documentDescription}
                onChange={(e) => setDocumentDescription(e.target.value)}
              />
            </div>
            
            <div>
              <label htmlFor="tags" className="text-sm font-medium">
                Etiquetas (opcional, separadas por comas)
              </label>
              <Input
                id="tags"
                placeholder="resistencia, capacitor, análisis"
                className="mt-1"
                value={documentTags}
                onChange={(e) => setDocumentTags(e.target.value)}
              />
            </div>
          </div>
          
          {isUploadingDocument && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subiendo...</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => {
              setShowKnowledgeDialog(false);
              setSelectedFiles(null);
              setDocumentDescription("");
              setDocumentTags("");
            }}
          >
            Cancelar
          </Button>
          <Button 
            onClick={() => {
              if (!selectedFiles || selectedFiles.length === 0) return;
              
              // Simulación de subida
              setIsUploadingDocument(true);
              
              const uploadProgress = setInterval(() => {
                setUploadProgress(prev => {
                  const newProgress = prev + Math.floor(Math.random() * 10);
                  if (newProgress >= 100) {
                    clearInterval(uploadProgress);
                    
                    // Crear nuevos documentos
                    const newDocs = selectedFiles ? Array.from(selectedFiles).map(file => {
                      const fileType = file.type.startsWith('image/') 
                        ? 'image' 
                        : file.name.endsWith('.pdf') 
                          ? 'pdf' 
                          : file.name.endsWith('.txt') 
                            ? 'txt' 
                            : 'doc';
                      
                      return {
                        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
                        name: file.name,
                        type: fileType as 'pdf' | 'txt' | 'doc' | 'image',
                        path: '/uploads/' + file.name,
                        addedAt: new Date(),
                        description: documentDescription,
                        tags: documentTags.split(',').map(tag => tag.trim()).filter(tag => tag),
                        status: 'ready' as 'processing' | 'ready' | 'error'
                      };
                    }) : [];
                    
                    setKnowledgeDocuments(prev => [...prev, ...newDocs]);
                    
                    // Pequeño retraso antes de cerrar
                    setTimeout(() => {
                      setIsUploadingDocument(false);
                      setUploadProgress(0);
                      setSelectedFiles(null);
                      setDocumentDescription("");
                      setDocumentTags("");
                      setShowKnowledgeDialog(false);
                      
                      toast({
                        title: "Documentos añadidos",
                        description: `Se han añadido ${newDocs.length} documento(s) a la base de conocimiento.`,
                      });
                    }, 500);
                    
                    return 100;
                  }
                  return newProgress;
                });
              }, 200);
              
            }}
            disabled={!selectedFiles || selectedFiles.length === 0 || isUploadingDocument}
          >
            Subir Documento
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}