#!/bin/bash

# Crear directorios necesarios
mkdir -p templates static static/previews uploads outputs results data

# Ejecutar la aplicación
python web_app.py