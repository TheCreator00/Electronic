import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, formatISO } from 'date-fns';
import { Loader2 } from 'lucide-react';

import { formatDateForAPI, getDaysInMonth } from '@/lib/date';
import CalendarView from '@/components/CalendarView';
import { HabitWithCheckIn, HabitCheckIn } from '@shared/schema';

export default function Calendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  // Get boundaries for the current month
  const startDate = formatDateForAPI(startOfMonth(currentMonth));
  const endDate = formatDateForAPI(endOfMonth(currentMonth));
  
  // Fetch habits for the month
  const { data: habits, isLoading: habitsLoading } = useQuery<HabitWithCheckIn[]>({
    queryKey: ['/api/habits'],
  });
  
  // Fetch check-ins for the month
  const { data: checkIns, isLoading: checkInsLoading } = useQuery<HabitCheckIn[]>({
    queryKey: ['/api/habits/date', startDate, endDate],
    queryFn: async () => {
      const res = await fetch(`/api/check-ins?start=${startDate}&end=${endDate}`);
      if (!res.ok) throw new Error('Failed to fetch check-ins');
      return res.json();
    },
    enabled: !!habits, // Only fetch check-ins if habits are loaded
  });
  
  // Navigate to previous month
  const goToPreviousMonth = () => {
    setCurrentMonth(prevMonth => subMonths(prevMonth, 1));
  };
  
  // Navigate to next month
  const goToNextMonth = () => {
    setCurrentMonth(prevMonth => addMonths(prevMonth, 1));
  };
  
  // Go to current month
  const goToCurrentMonth = () => {
    setCurrentMonth(new Date());
  };
  
  const isLoading = habitsLoading || checkInsLoading;
  
  const daysInMonth = getDaysInMonth(currentMonth);
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Calendar</h1>
        <div className="flex items-center space-x-2">
          <button 
            className="p-2 rounded-lg hover:bg-gray-200"
            onClick={goToPreviousMonth}
            aria-label="Previous month"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </button>
          <div 
            className="font-medium cursor-pointer"
            onClick={goToCurrentMonth}
          >
            {format(currentMonth, 'MMMM yyyy')}
          </div>
          <button 
            className="p-2 rounded-lg hover:bg-gray-200"
            onClick={goToNextMonth}
            aria-label="Next month"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <CalendarView 
            month={currentMonth}
            days={daysInMonth}
            habits={habits || []}
          />
          
          <div className="flex mt-4 text-sm">
            <div className="flex items-center mr-4">
              <div className="w-3 h-3 bg-success rounded-full mr-1.5"></div>
              <span>All Complete</span>
            </div>
            <div className="flex items-center mr-4">
              <div className="w-3 h-3 bg-warning rounded-full mr-1.5"></div>
              <span>Partial</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-danger rounded-full mr-1.5"></div>
              <span>Missed</span>
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Upcoming Habits</h2>
        
        {isLoading ? (
          <div className="flex justify-center py-4">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-4">
            {habits && habits.length > 0 ? (
              habits.slice(0, 5).map(habit => (
                <div key={habit.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <span className={`inline-block w-2 h-2 rounded-full bg-${habit.category} mr-2`}></span>
                    <span className="font-medium">{habit.name}</span>
                  </div>
                  <div className="text-sm text-gray-500">
                    {habit.streak > 0 ? (
                      <span className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-orange-500 mr-1" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z" />
                        </svg>
                        {habit.streak} days
                      </span>
                    ) : (
                      "No streak yet"
                    )}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-4">No habits found.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
