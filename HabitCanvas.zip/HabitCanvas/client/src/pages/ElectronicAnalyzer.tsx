import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect, useRef } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { CustomBadge } from "@/components/ui/custom-badge";

// Tipo para los mensajes del chat
interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
  attachments?: {
    type: 'image' | 'file';
    url: string;
    name: string;
  }[];
  usedDocuments?: string[]; // IDs de documentos de la base de conocimiento utilizados
}

// Tipo para los documentos de conocimiento
interface KnowledgeDocument {
  id: string;
  name: string;
  type: 'pdf' | 'txt' | 'doc' | 'image';
  path: string;
  addedAt: Date;
  description?: string;
  tags: string[];
  status: 'processing' | 'ready' | 'error';
}

export default function ElectronicAnalyzer() {
  const [activeTab, setActiveTab] = useState("chat");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [selectedModel, setSelectedModel] = useState("grok");
  const [isModelSwitching, setIsModelSwitching] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  const [knowledgeDocuments, setKnowledgeDocuments] = useState<KnowledgeDocument[]>([]);
  const [showKnowledgeDialog, setShowKnowledgeDialog] = useState(false);
  const [documentDescription, setDocumentDescription] = useState("");
  const [documentTags, setDocumentTags] = useState("");
  const [isUploadingDocument, setIsUploadingDocument] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const knowledgeFileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  // Referencia para WebSocket
  const websocketRef = useRef<WebSocket | null>(null);
  
  // Cuando se monta el componente, mostrar mensaje de bienvenida y conectar WebSocket
  useEffect(() => {
    // Mostrar el mensaje de bienvenida inmediatamente al cargar
    const welcomeMessage: ChatMessage = {
      id: "welcome",
      sender: "ai",
      content: "¡Hola! Soy el asistente de análisis electrónico. Puedo ayudarte a identificar componentes y analizar circuitos.\n\nPuedo hacer lo siguiente:\n• Identificar componentes en imágenes\n• Analizar diagramas de circuitos\n• Responder preguntas sobre electrónica\n• Utilizar documentos PDF y TXT como fuentes de conocimiento\n\nSube una imagen o toma una foto para comenzar, o pregúntame cualquier duda sobre componentes electrónicos.",
      timestamp: new Date()
    };
    setMessages([welcomeMessage]);
    
    // Inicializar WebSocket
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    websocketRef.current = socket;
    
    // Manejar apertura de conexión
    socket.addEventListener('open', () => {
      console.log('WebSocket connection established');
      
      // Solicitar el estado de los modelos de IA
      socket.send(JSON.stringify({
        type: 'status'
      }));
    });
    
    // Manejar mensajes recibidos
    socket.addEventListener('message', (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log('WebSocket message received:', data);
        
        // Manejar diferentes tipos de mensajes
        if (data.type === 'system') {
          // Mensaje del sistema (conexión, etc.)
          toast({
            title: "Sistema",
            description: data.message,
          });
        } 
        else if (data.type === 'chat') {
          // Respuesta de chat desde el servidor
          const aiResponse: ChatMessage = {
            id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
            sender: "ai",
            content: data.message,
            timestamp: new Date(),
            usedDocuments: data.usedDocuments
          };
          
          // Si hay adjuntos en la respuesta, agregarlos
          if (data.attachments && data.attachments.length > 0) {
            aiResponse.attachments = data.attachments.map((att: any) => ({
              type: att.type,
              url: `data:${att.type === 'image' ? 'image/jpeg' : 'application/octet-stream'};base64,${att.data}`,
              name: att.name
            }));
          }
          
          setMessages(prev => [...prev, aiResponse]);
          setIsTyping(false);
        }
        else if (data.type === 'typing') {
          // Actualizar estado de typing
          setIsTyping(data.status);
        }
        else if (data.type === 'status') {
          // Actualizar estado de modelos disponibles
          console.log('AI Models status:', data);
          
          // Si el modelo actual no está disponible, cambiar a uno que sí lo está
          if (selectedModel === 'grok' && !data.grok) {
            setSelectedModel('local');
            toast({
              title: "Modelo cambiado",
              description: "El modelo Grok no está disponible. Cambiando a modelo Local.",
              variant: "default"
            });
          } else if (selectedModel === 'hybrid' && !data.hybrid) {
            setSelectedModel('local');
            toast({
              title: "Modelo cambiado",
              description: "El modelo Híbrido no está disponible. Cambiando a modelo Local.",
              variant: "default"
            });
          }
        }
        else if (data.type === 'error') {
          // Mostrar error
          toast({
            title: "Error",
            description: data.message,
            variant: "destructive"
          });
          setIsTyping(false);
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    // Manejar errores
    socket.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
      toast({
        title: "Error de conexión",
        description: "No se pudo conectar con el servidor. Las respuestas serán generadas localmente.",
        variant: "destructive"
      });
    });
    
    // Manejar cierre de conexión
    socket.addEventListener('close', () => {
      console.log('WebSocket connection closed');
      websocketRef.current = null;
      
      // No necesitamos agregar mensaje de bienvenida aquí ya que ya lo hicimos al inicio
    });
    
    // Cleanup al desmontar
    return () => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, []);

  // Hacer scroll hasta el final cuando se añaden nuevos mensajes
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);
  
  // Cargar documentos de la base de conocimiento
  useEffect(() => {
    fetch('/api/xai/knowledge')
      .then(response => {
        if (response.ok) return response.json();
        throw new Error('Failed to fetch knowledge documents');
      })
      .then(data => {
        setKnowledgeDocuments(data);
      })
      .catch(error => {
        console.error('Error fetching knowledge documents:', error);
      });
  }, []);
  
  // Manejar la subida de archivos
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setSelectedFiles(event.target.files);
    }
  };

  // Enviar un mensaje
  const sendMessage = () => {
    if (inputValue.trim() === "" && (!selectedFiles || selectedFiles.length === 0)) return;
    
    // Crear y añadir el mensaje del usuario
    const newUserMessage: ChatMessage = {
      id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
      sender: "user",
      content: inputValue,
      timestamp: new Date(),
    };
    
    // Preparar datos para WebSocket
    const wsMessage: any = {
      type: 'chat',
      message: inputValue,
      model: selectedModel,
    };
    
    // Añadir archivos adjuntos si los hay
    if (selectedFiles && selectedFiles.length > 0) {
      const filePromises = Array.from(selectedFiles).map(file => {
        const isImage = file.type.startsWith("image/");
        
        // Guardar URL para visualización local
        const localUrl = URL.createObjectURL(file);
        
        // Para WebSocket, convertir a base64
        return new Promise<{type: 'image' | 'file', data: string, name: string}>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            // reader.result contiene los datos como base64
            resolve({
              type: isImage ? 'image' : 'file',
              data: reader.result as string, 
              name: file.name
            });
          };
          
          if (isImage) {
            reader.readAsDataURL(file);
          } else {
            // Para archivos de texto, leer como texto
            reader.readAsText(file);
          }
        });
      });
      
      // Agregar URLs locales para visualización
      newUserMessage.attachments = Array.from(selectedFiles).map(file => {
        const isImage = file.type.startsWith("image/");
        return {
          type: isImage ? 'image' : 'file',
          url: URL.createObjectURL(file),
          name: file.name
        };
      });
      
      // Cuando todos los archivos se hayan procesado, enviar mensaje
      Promise.all(filePromises).then(attachments => {
        wsMessage.attachments = attachments;
        
        // Enviar al WebSocket si está disponible
        if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
          websocketRef.current.send(JSON.stringify(wsMessage));
        } else {
          handleFallbackResponse(newUserMessage);
        }
      });
    } else {
      // Enviar al WebSocket si está disponible
      if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
        websocketRef.current.send(JSON.stringify(wsMessage));
      } else {
        handleFallbackResponse(newUserMessage);
      }
    }
    
    // Agregar mensaje a la UI inmediatamente
    setMessages(prev => [...prev, newUserMessage]);
    setInputValue("");
    setSelectedFiles(null);
    
    // Si no estamos usando WebSocket, mostrar indicador de typing
    if (!websocketRef.current || websocketRef.current.readyState !== WebSocket.OPEN) {
      setIsTyping(true);
    }
  };
  
  // Manejar respuesta sin WebSocket (fallback)
  const handleFallbackResponse = (userMessage: ChatMessage) => {
    setTimeout(() => {
      // Si el mensaje contiene palabras clave, enviar respuestas específicas
      const inputContent = userMessage.content.toLowerCase();
      
      if (inputContent.includes("resistencia") || 
          inputContent.includes("resistor") || 
          (userMessage.attachments && userMessage.attachments.some(a => a.name.toLowerCase().includes("resistencia")))) {
        
        const aiResponse: ChatMessage = {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
          sender: "ai",
          content: "Las resistencias son componentes fundamentales que limitan el flujo de corriente. Se clasifican por su valor en ohmios (Ω) y potencia en vatios (W).\n\nCódigo de colores:\n- Negro: 0\n- Marrón: 1\n- Rojo: 2\n- Naranja: 3\n- Amarillo: 4\n- Verde: 5\n- Azul: 6\n- Violeta: 7\n- Gris: 8\n- Blanco: 9\n\nPara una resistencia de 4 bandas, las primeras dos bandas indican dígitos, la tercera es el multiplicador, y la cuarta la tolerancia.",
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, aiResponse]);
        
      } else if (inputContent.includes("capacitor") || 
                 inputContent.includes("condensador") || 
                 (userMessage.attachments && userMessage.attachments.some(a => a.name.toLowerCase().includes("capacitor")))) {
        
        const aiResponse: ChatMessage = {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
          sender: "ai",
          content: "Los capacitores almacenan carga eléctrica temporalmente. Se clasifican por su capacitancia (en faradios: F, μF, nF, pF) y voltaje máximo.\n\nTipos principales:\n- Electrolíticos: Alta capacitancia, polarizados\n- Cerámicos: Para altas frecuencias, no polarizados\n- Película: Buena estabilidad, baja tolerancia\n- Tantalio: Compactos, alta capacitancia\n\nUsos: filtrado, acoplamiento/desacoplamiento, temporización, y almacenamiento de energía.",
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, aiResponse]);
        
      } else if (userMessage.attachments && userMessage.attachments.some(a => a.type === 'image')) {
        // Si hay una imagen adjunta, simulamos análisis de circuito
        const imageUrl = userMessage.attachments.find(a => a.type === 'image')?.url;
        
        // Respuesta específica para análisis de imagen
        const aiResponse: ChatMessage = {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
          sender: "ai",
          content: "He analizado la imagen y he detectado varios componentes:\n\n- 3 Resistencias (R1: 10kΩ, R2: 4.7kΩ, R3: 1kΩ)\n- 2 Capacitores (C1: 10μF, C2: 100nF)\n- 1 Transistor NPN (posiblemente 2N2222)\n- 1 Diodo LED\n\nEste parece ser un circuito amplificador básico con filtro RC. Las resistencias R1 y R2 forman un divisor de voltaje para polarizar la base del transistor, mientras que R3 es la resistencia de colector. C1 bloquea DC y C2 filtra ruido de alta frecuencia.",
          timestamp: new Date(),
          attachments: imageUrl ? [{
            type: 'image',
            url: imageUrl,
            name: 'analisis_circuito.jpg'
          }] : undefined
        };
        
        setMessages(prev => [...prev, aiResponse]);
        
      } else {
        // Respuesta genérica
        const aiResponse: ChatMessage = {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
          sender: "ai",
          content: "Gracias por tu consulta. Para analizar componentes electrónicos específicos, te recomiendo subir una imagen del circuito o componente. También puedo responder preguntas sobre resistencias, capacitores, diodos, transistores y otros componentes comunes.",
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, aiResponse]);
      }
      
      setIsTyping(false);
    }, 1500);
  };

  // Cambiar el modelo de IA
  const switchModel = (model: string) => {
    setIsModelSwitching(true);
    
    setTimeout(() => {
      setSelectedModel(model);
      setIsModelSwitching(false);
      
      toast({
        title: "Modelo cambiado",
        description: `Ahora usando el modelo de IA: ${model === 'grok' ? 'Grok (xAI)' : model === 'local' ? 'Local' : 'Híbrido'}`,
      });
      
      // Mensaje del sistema sobre el cambio
      const systemMessage: ChatMessage = {
        id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
        sender: "ai",
        content: `He cambiado al modelo ${model === 'grok' ? 'Grok de xAI' : model === 'local' ? 'Local (procesamiento en dispositivo)' : 'Híbrido (combinación local + API)'}.${model === 'local' ? ' Este modelo tiene capacidades limitadas pero funciona sin conexión.' : model === 'hybrid' ? ' Este modelo combina análisis local con consultas a la API para resultados óptimos.' : ' Este modelo ofrece análisis avanzado mediante la API de xAI.'}`,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, systemMessage]);
    }, 1000);
  };

  // Iniciar captura de cámara
  const startCapture = async () => {
    setIsCapturing(true);
    
    try {
      if (videoRef.current && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast({
        title: "Error de cámara",
        description: "No se pudo acceder a la cámara. Verifica los permisos.",
        variant: "destructive"
      });
      setIsCapturing(false);
    }
  };

  // Capturar foto
  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      
      if (context) {
        // Establecer dimensiones del canvas
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        
        // Dibujar el frame actual
        context.drawImage(videoRef.current, 0, 0);
        
        // Convertir a dataURL
        const imageDataUrl = canvasRef.current.toDataURL('image/jpeg');
        
        // Detener la transmisión de vídeo
        const stream = videoRef.current.srcObject as MediaStream;
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());
        videoRef.current.srcObject = null;
        
        // Reiniciar estado
        setIsCapturing(false);
        
        // Crear un archivo a partir del dataURL
        fetch(imageDataUrl)
          .then(res => res.blob())
          .then(blob => {
            const file = new File([blob], "captura.jpg", { type: "image/jpeg" });
            const fileList = new DataTransfer();
            fileList.items.add(file);
            setSelectedFiles(fileList.files);
            
            // Enviar mensaje con la foto
            setInputValue("Análisis de componentes en la foto capturada");
            setTimeout(() => sendMessage(), 300);
          });
      }
    }
  };

  // Cancelar captura
  const cancelCapture = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCapturing(false);
  };

  // Renderizar un mensaje
  const renderMessage = (message: ChatMessage) => {
    // Buscar documentos utilizados
    const usedDocs = message.usedDocuments && message.usedDocuments.length > 0
      ? message.usedDocuments.map(docId => 
          knowledgeDocuments.find(doc => doc.id === docId)
        ).filter(doc => doc !== undefined)
      : [];
      
    return (
      <div 
        key={message.id} 
        className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
      >
        <div 
          className={`max-w-[80%] ${message.sender === 'user' ? 'bg-primary text-primary-foreground rounded-tl-2xl rounded-tr-sm rounded-bl-2xl rounded-br-2xl' : 'bg-muted rounded-tl-sm rounded-tr-2xl rounded-bl-2xl rounded-br-2xl'} p-3 shadow-sm`}
        >
          {/* Contenido del mensaje */}
          <div className="whitespace-pre-line text-sm">{message.content}</div>
          
          {/* Documentos utilizados */}
          {usedDocs.length > 0 && (
            <div className="mt-2 pt-2 border-t border-border">
              <div className="text-xs font-medium mb-1 text-muted-foreground">Fuentes consultadas:</div>
              <div className="flex flex-wrap gap-1">
                {usedDocs.map((doc, index) => (
                  <Badge 
                    key={doc!.id} 
                    variant="outline" 
                    className="text-[10px] flex items-center gap-1"
                  >
                    {doc!.type === 'pdf' ? (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                      </svg>
                    ) : doc!.type === 'image' ? (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    )}
                    {doc!.name}
                  </Badge>
                ))}
              </div>
            </div>
          )}
          
          {/* Archivos adjuntos */}
          {message.attachments && message.attachments.length > 0 && (
            <div className="mt-2 space-y-2">
              {message.attachments.map((attachment, index) => (
                <div key={index}>
                  {attachment.type === 'image' && (
                    <img 
                      src={attachment.url} 
                      alt={attachment.name} 
                      className="rounded-md max-h-60 object-contain mb-1 border border-border"
                    />
                  )}
                  <div className="text-xs opacity-80">{attachment.name}</div>
                </div>
              ))}
            </div>
          )}
          
          {/* Timestamp */}
          <div className={`text-xs mt-1 ${message.sender === 'user' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
            {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col">
      <div className="container mx-auto p-4 max-w-6xl">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold mr-4">Analizador Electrónico</h1>
              <div className="bg-muted py-1 px-3 rounded-full text-xs flex items-center space-x-1">
                <div className="h-2 w-2 rounded-full bg-green-500"></div>
                <span>Sistema activo</span>
              </div>
            </div>
            
            <TabsList className="grid w-[400px] grid-cols-2">
              <TabsTrigger value="chat">Chat</TabsTrigger>
              <TabsTrigger value="knowledge">Base de Conocimiento</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="chat" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="col-span-3">
                <Card className="h-[600px] flex flex-col">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-xl">Asistente Electrónico</CardTitle>
                      <div className="flex items-center space-x-2">
                        <CustomBadge status={isModelSwitching ? 'loading' : 'success'}>
                          {isModelSwitching ? 'Cambiando...' : `Modelo: ${selectedModel === 'grok' ? 'Grok (xAI)' : selectedModel === 'local' ? 'Local' : 'Híbrido'}`}
                        </CustomBadge>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                              </svg>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => switchModel('grok')} className={selectedModel === 'grok' ? 'bg-muted' : ''}>
                              Usar Grok (xAI)
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => switchModel('local')} className={selectedModel === 'local' ? 'bg-muted' : ''}>
                              Usar modelo Local
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => switchModel('hybrid')} className={selectedModel === 'hybrid' ? 'bg-muted' : ''}>
                              Usar modelo Híbrido
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <CardDescription>
                      Haz preguntas sobre electrónica o sube imágenes para análisis de componentes
                    </CardDescription>
                    <Separator className="mt-2" />
                  </CardHeader>
                  
                  <CardContent className="flex-grow overflow-hidden flex flex-col h-full">
                    {isCapturing ? (
                      <div className="flex flex-col items-center justify-center h-full p-4">
                        <div className="relative w-full max-w-md overflow-hidden rounded-lg border-2 border-dashed border-muted-foreground/30 mb-4">
                          <video 
                            ref={videoRef} 
                            className="w-full h-auto"
                            autoPlay
                            playsInline
                            muted
                          />
                        </div>
                        <div className="flex space-x-2">
                          <Button onClick={capturePhoto} className="flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            Capturar
                          </Button>
                          <Button variant="outline" onClick={cancelCapture}>
                            Cancelar
                          </Button>
                        </div>
                        <canvas ref={canvasRef} className="hidden" />
                      </div>
                    ) : (
                      <ScrollArea className="h-full pr-4">
                        <div className="space-y-4 p-1">
                          {messages.map(renderMessage)}
                          {isTyping && (
                            <div className="flex justify-start mb-4">
                              <div className="bg-muted rounded-xl p-3 shadow-sm max-w-[80%]">
                                <div className="flex space-x-2">
                                  <div className="w-2 h-2 rounded-full bg-foreground/30 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                                  <div className="w-2 h-2 rounded-full bg-foreground/30 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                                  <div className="w-2 h-2 rounded-full bg-foreground/30 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                                </div>
                              </div>
                            </div>
                          )}
                          <div ref={chatEndRef} />
                        </div>
                      </ScrollArea>
                    )}
                  </CardContent>
                  
                  <CardFooter className="pt-2">
                    <div className="relative w-full flex flex-col">
                      {selectedFiles && selectedFiles.length > 0 && (
                        <div className="flex items-center space-x-2 bg-muted p-2 rounded-md mb-2">
                          <div className="flex-grow truncate">
                            {Array.from(selectedFiles).map((file, i) => (
                              <span key={i} className="text-xs">
                                {file.name}{i < selectedFiles.length - 1 ? ', ' : ''}
                              </span>
                            ))}
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-6 w-6 p-0" 
                            onClick={() => setSelectedFiles(null)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </Button>
                        </div>
                      )}
                      
                      <div className="flex space-x-2">
                        <div className="flex-grow flex">
                          <Input
                            placeholder="Escribe tu mensaje..."
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                            className="rounded-r-none flex-grow"
                            disabled={isTyping}
                          />
                          <Button 
                            variant="outline" 
                            className="rounded-l-none border-l-0"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={isTyping}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                            </svg>
                            <input
                              type="file"
                              className="hidden"
                              ref={fileInputRef}
                              onChange={handleFileChange}
                              accept="image/*,.pdf,.txt"
                            />
                          </Button>
                        </div>
                        <Button variant="outline" onClick={startCapture} disabled={isTyping}>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                        </Button>
                        <Button onClick={sendMessage} disabled={isTyping}>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                          </svg>
                        </Button>
                      </div>
                    </div>
                  </CardFooter>
                </Card>
              </div>
              
              <div className="col-span-1">
                <Card className="h-[600px]">
                  <CardHeader>
                    <CardTitle className="text-lg">Componentes Detectados</CardTitle>
                    <CardDescription>
                      Resultados del último análisis
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[calc(600px-8rem)] overflow-auto space-y-4">
                    <Card className="border border-primary/20">
                      <CardHeader className="p-3 pb-1">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Resistencia
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-3 pt-0">
                        <div className="text-xs text-muted-foreground">
                          <p>Valor: <span className="font-medium text-foreground">10kΩ ±5%</span></p>
                          <p>Código de colores: Marrón-Negro-Naranja-Dorado</p>
                          <p>Potencia estimada: 0.25W</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="border border-primary/20">
                      <CardHeader className="p-3 pb-1">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Capacitor
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-3 pt-0">
                        <div className="text-xs text-muted-foreground">
                          <p>Tipo: <span className="font-medium text-foreground">Electrolítico</span></p>
                          <p>Capacitancia: 100μF ±20%</p>
                          <p>Voltaje máximo: 16V</p>
                          <p className="text-amber-500">⚠️ Polarizado - Verificar orientación</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="border border-primary/20">
                      <CardHeader className="p-3 pb-1">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Transistor
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-3 pt-0">
                        <div className="text-xs text-muted-foreground">
                          <p>Tipo: <span className="font-medium text-foreground">NPN</span></p>
                          <p>Modelo identificado: 2N2222</p>
                          <p>Pines: 1-Base, 2-Colector, 3-Emisor</p>
                        </div>
                      </CardContent>
                    </Card>
                  </CardContent>
                  <CardFooter className="text-xs text-muted-foreground pt-0">
                    Último análisis: {new Date().toLocaleString()}
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="knowledge" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-xl">Base de Conocimiento</CardTitle>
                  <Button 
                    size="sm" 
                    onClick={() => setShowKnowledgeDialog(true)}
                    className="flex items-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Añadir Documento
                  </Button>
                </div>
                <CardDescription>
                  Documentos y recursos para mejorar las respuestas de IA
                </CardDescription>
              </CardHeader>
              <CardContent>
                {knowledgeDocuments.length === 0 ? (
                  <div className="text-center py-10 text-muted-foreground">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto mb-4 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <h3 className="font-medium mb-1">No hay documentos</h3>
                    <p className="text-sm">Añade manuales técnicos, datasheets, o imágenes de referencia para mejorar el análisis.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex justify-between mb-2 text-sm font-medium text-muted-foreground">
                      <span>Nombre</span>
                      <div className="flex">
                        <span className="w-24 text-center">Tipo</span>
                        <span className="w-24 text-center">Estado</span>
                        <span className="w-24 text-center">Acciones</span>
                      </div>
                    </div>
                    
                    {knowledgeDocuments.map(doc => (
                      <div key={doc.id} className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/40 transition-colors">
                        <div className="flex items-center space-x-3 truncate">
                          <div className="p-2 bg-primary/10 rounded-md">
                            {doc.type === 'pdf' ? (
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-rose-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                              </svg>
                            ) : doc.type === 'image' ? (
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-cyan-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                              </svg>
                            ) : (
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                            )}
                          </div>
                          <div className="truncate">
                            <div className="font-medium truncate">{doc.name}</div>
                            <div className="text-xs text-muted-foreground truncate">
                              {doc.description || "Sin descripción"}
                            </div>
                            <div className="flex mt-1 gap-1">
                              {doc.tags.map(tag => (
                                <Badge key={tag} variant="secondary" className="text-[10px] px-1 py-0 h-4">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          <div className="w-24 text-center">
                            <Badge variant="outline" className="capitalize">
                              {doc.type}
                            </Badge>
                          </div>
                          <div className="w-24 text-center">
                            <CustomBadge status={
                              doc.status === 'ready' ? 'success' : 
                              doc.status === 'processing' ? 'loading' : 'error'
                            }>
                              {doc.status === 'ready' 
                                ? 'Listo' 
                                : doc.status === 'processing' 
                                  ? 'Procesando' 
                                  : 'Error'}
                            </CustomBadge>
                          </div>
                          <div className="w-24 flex justify-center">
                            <Button variant="ghost" size="sm" className="px-1">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                            </Button>
                            <Button variant="ghost" size="sm" className="px-1"
                              onClick={() => {
                                setKnowledgeDocuments(prev => prev.filter(d => d.id !== doc.id));
                                toast({
                                  title: "Documento eliminado",
                                  description: `Se ha eliminado "${doc.name}" de la base de conocimiento.`,
                                });
                              }}
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showKnowledgeDialog} onOpenChange={setShowKnowledgeDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Añadir documento a la base de conocimiento</DialogTitle>
            <DialogDescription>
              Sube documentos técnicos, manuales o imágenes para mejorar el análisis y las respuestas.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {!selectedFiles || selectedFiles.length === 0 ? (
              <div 
                className="border-2 border-dashed rounded-lg p-10 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => knowledgeFileInputRef.current?.click()}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mx-auto mb-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <div className="text-muted-foreground">
                  <p className="mb-1 font-medium">Haz clic para seleccionar o arrastra archivos aquí</p>
                  <p className="text-sm">Archivos PDF, TXT, DOC(X) o imágenes</p>
                </div>
                <input
                  type="file"
                  className="hidden"
                  ref={knowledgeFileInputRef}
                  onChange={handleFileChange}
                  accept=".pdf,.txt,.doc,.docx,image/*"
                  multiple
                />
              </div>
            ) : (
              <div className="border rounded-lg p-4">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="font-medium">Archivos seleccionados</h4>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSelectedFiles(null)}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </Button>
                </div>
                
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {selectedFiles && Array.from(selectedFiles).map((file, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        <span>{file.name}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {Math.round(file.size / 1024)} KB
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="space-y-3">
              <div>
                <label htmlFor="description" className="text-sm font-medium">
                  Descripción (opcional)
                </label>
                <Textarea
                  id="description"
                  placeholder="Añade una descripción para este documento"
                  className="mt-1"
                  value={documentDescription}
                  onChange={(e) => setDocumentDescription(e.target.value)}
                />
              </div>
              
              <div>
                <label htmlFor="tags" className="text-sm font-medium">
                  Etiquetas (opcional, separadas por comas)
                </label>
                <Input
                  id="tags"
                  placeholder="resistencia, capacitor, análisis"
                  className="mt-1"
                  value={documentTags}
                  onChange={(e) => setDocumentTags(e.target.value)}
                />
              </div>
            </div>
            
            {isUploadingDocument && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subiendo...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setShowKnowledgeDialog(false);
                setSelectedFiles(null);
                setDocumentDescription("");
                setDocumentTags("");
              }}
            >
              Cancelar
            </Button>
            <Button 
              onClick={() => {
                if (!selectedFiles || selectedFiles.length === 0) return;
                
                // Iniciar proceso de subida
                setIsUploadingDocument(true);
                setUploadProgress(0);
                
                // Procesar cada archivo seleccionado
                const uploadPromises = Array.from(selectedFiles).map(file => {
                  const fileType = file.type.startsWith('image/') 
                    ? 'image' 
                    : file.name.endsWith('.pdf') 
                      ? 'pdf' 
                      : file.name.endsWith('.txt') 
                        ? 'txt' 
                        : 'doc';
                  
                  // Crear objeto de documento
                  const document = {
                    id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
                    name: file.name,
                    type: fileType as 'pdf' | 'txt' | 'doc' | 'image',
                    path: '', // Será asignado por el servidor
                    addedAt: new Date(),
                    description: documentDescription,
                    tags: documentTags.split(',').map(tag => tag.trim()).filter(tag => tag),
                    status: 'processing' as 'processing' | 'ready' | 'error'
                  };
                  
                  // Leer el archivo como base64 o texto según el tipo
                  return new Promise<{document: KnowledgeDocument, fileData: string}>((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = () => {
                      resolve({
                        document,
                        fileData: reader.result as string
                      });
                    };
                    reader.onerror = () => {
                      reject(new Error(`Error al leer el archivo ${file.name}`));
                    };
                    
                    if (fileType === 'image') {
                      reader.readAsDataURL(file);
                    } else {
                      reader.readAsText(file);
                    }
                  });
                });
                
                // Actualizar progreso artificial
                const progressInterval = setInterval(() => {
                  setUploadProgress(prev => {
                    const newProgress = Math.min(prev + 5, 90); // Max 90% para progreso artificial
                    return newProgress;
                  });
                }, 200);
                
                // Cuando todos los archivos estén leídos, subirlos al servidor
                Promise.all(uploadPromises)
                  .then(results => {
                    // Subir los documentos al servidor uno por uno
                    return Promise.all(results.map(({document, fileData}) => {
                      return fetch('/api/xai/knowledge', {
                        method: 'POST',
                        headers: {
                          'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                          document,
                          fileData
                        })
                      })
                      .then(response => {
                        if (!response.ok) {
                          throw new Error(`Error al subir ${document.name}`);
                        }
                        return response.json();
                      });
                    }));
                  })
                  .then(responses => {
                    // Detener el intervalo de progreso
                    clearInterval(progressInterval);
                    
                    // Establecer progreso al 100%
                    setUploadProgress(100);
                    
                    // Agregar documentos a la lista
                    const newDocs = responses.map(res => res.document);
                    setKnowledgeDocuments(prev => [...prev, ...newDocs]);
                    
                    // Limpiar y cerrar el diálogo
                    setTimeout(() => {
                      setIsUploadingDocument(false);
                      setUploadProgress(0);
                      setSelectedFiles(null);
                      setDocumentDescription("");
                      setDocumentTags("");
                      setShowKnowledgeDialog(false);
                      
                      toast({
                        title: "Documentos añadidos",
                        description: `Se han añadido ${newDocs.length} documento(s) a la base de conocimiento.`,
                      });
                    }, 500);
                  })
                  .catch(error => {
                    // Manejar errores
                    console.error("Error al subir documentos:", error);
                    
                    clearInterval(progressInterval);
                    setIsUploadingDocument(false);
                    
                    toast({
                      title: "Error al subir documentos",
                      description: error.message || "Hubo un problema al subir los documentos.",
                      variant: "destructive"
                    });
                  });
              }}
              disabled={!selectedFiles || selectedFiles.length === 0 || isUploadingDocument}
            >
              Subir Documento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}