import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Loader2, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

import { queryClient, apiRequest } from '@/lib/queryClient';
import { Switch } from '@/components/ui/switch';
import { HabitWithFrequency } from '@shared/schema';
import { getCategoryColor } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Settings() {
  const { toast } = useToast();
  const [habitToDelete, setHabitToDelete] = useState<HabitWithFrequency | null>(null);
  
  // Fetch all habits
  const { data: habits, isLoading } = useQuery<HabitWithFrequency[]>({
    queryKey: ['/api/habits'],
  });
  
  // Delete habit mutation
  const deleteHabitMutation = useMutation({
    mutationFn: async (habitId: number) => {
      return apiRequest('DELETE', `/api/habits/${habitId}`);
    },
    onSuccess: () => {
      toast({
        title: "Habit deleted",
        description: "The habit has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      setHabitToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete habit: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleDeleteHabit = () => {
    if (habitToDelete) {
      deleteHabitMutation.mutate(habitToDelete.id);
    }
  };
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Manage Habits</h2>
        
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {!habits || habits.length === 0 ? (
              <p className="text-gray-500 text-center py-4">
                You don't have any habits yet. Go to the dashboard to create your first habit.
              </p>
            ) : (
              <div className="space-y-4">
                {habits.map((habit) => (
                  <div key={habit.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className={`w-2 h-10 bg-${getCategoryColor(habit.category)} rounded-l-md mr-3`} />
                      <div>
                        <h3 className="font-medium">{habit.name}</h3>
                        <p className="text-sm text-gray-500">{habit.description}</p>
                      </div>
                    </div>
                    <button
                      className="p-2 text-gray-400 hover:text-red-500 focus:outline-none"
                      onClick={() => setHabitToDelete(habit)}
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Application Settings</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-2">
            <div>
              <h3 className="font-medium">Dark Mode</h3>
              <p className="text-sm text-gray-500">Enable dark mode for the application</p>
            </div>
            <Switch id="dark-mode" />
          </div>
          
          <div className="flex items-center justify-between p-2">
            <div>
              <h3 className="font-medium">Notifications</h3>
              <p className="text-sm text-gray-500">Enable notifications for habit reminders</p>
            </div>
            <Switch id="notifications" defaultChecked />
          </div>
          
          <div className="flex items-center justify-between p-2">
            <div>
              <h3 className="font-medium">Weekly Summary</h3>
              <p className="text-sm text-gray-500">Receive a weekly summary of your habits</p>
            </div>
            <Switch id="weekly-summary" defaultChecked />
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">About</h2>
        
        <div className="space-y-2">
          <p className="text-sm text-gray-500">
            HabitFlow is a habit tracking application designed to help you build better habits and routines.
          </p>
          <p className="text-sm text-gray-500">
            Version 1.0.0
          </p>
        </div>
      </div>
      
      {/* Confirmation Dialog */}
      <AlertDialog open={!!habitToDelete} onOpenChange={() => setHabitToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the habit "{habitToDelete?.name}" and all associated data. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteHabit}
              className="bg-red-500 hover:bg-red-600"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
