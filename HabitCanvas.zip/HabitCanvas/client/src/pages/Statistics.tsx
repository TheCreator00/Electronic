import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format, subDays } from 'date-fns';
import { Loader2 } from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend
} from 'recharts';

import { HabitStats } from '@shared/schema';
import StatsCard from '@/components/StatsCard';
import { formatPercentage } from '@/lib/utils';

// Time range options
const timeRanges = [
  { label: 'Last 7 days', value: 7 },
  { label: 'Last 30 days', value: 30 },
  { label: 'Last 90 days', value: 90 }
];

export default function Statistics() {
  const [timeRange, setTimeRange] = useState(30);
  
  // Fetch stats data
  const { data: stats, isLoading } = useQuery<HabitStats>({
    queryKey: ['/api/stats', timeRange],
    queryFn: async () => {
      const res = await fetch(`/api/stats?days=${timeRange}`);
      if (!res.ok) throw new Error('Failed to fetch statistics');
      return res.json();
    }
  });
  
  // Generate data for the streak chart
  const generateStreakData = () => {
    if (!stats) return [];
    
    // Create an array of days for the selected time range
    const data = [];
    const today = new Date();
    
    for (let i = timeRange - 1; i >= 0; i--) {
      const date = subDays(today, i);
      data.push({
        date: format(date, 'MMM dd'),
        streak: i < stats.currentStreak ? stats.currentStreak - i : 0
      });
    }
    
    return data;
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold">Statistics</h1>
        
        <div className="flex space-x-2">
          {timeRanges.map((range) => (
            <button
              key={range.value}
              className={`px-3 py-1.5 text-sm rounded-lg ${
                timeRange === range.value
                  ? 'bg-primary text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
              onClick={() => setTimeRange(range.value)}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <StatsCard
              title="Completion Rate"
              value={stats ? formatPercentage(stats.completionRate) : '0%'}
              description="Average completion rate"
              color="primary"
            />
            <StatsCard
              title="Current Streak"
              value={stats ? `${stats.currentStreak} days` : '0 days'}
              description="Days with all habits completed"
              color="secondary"
            />
            <StatsCard
              title="Best Streak"
              value={stats ? `${stats.bestStreak} days` : '0 days'}
              description="Longest streak for any habit"
              color="success"
            />
          </div>
          
          {/* Habit Trends Chart */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">Habit Completion Rates</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={stats?.habitTrends || []}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" domain={[0, 100]} tickFormatter={(value) => `${value}%`} />
                  <YAxis type="category" dataKey="habitName" width={150} />
                  <Tooltip formatter={(value) => [`${value}%`, 'Completion Rate']} />
                  <Bar dataKey="completionRate" fill="#3B82F6" barSize={20} radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          {/* Streak Chart */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">Current Streak</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={generateStreakData()}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="streak" stroke="#8B5CF6" strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
