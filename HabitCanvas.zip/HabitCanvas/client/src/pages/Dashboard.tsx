import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, addDays, subDays } from "date-fns";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

import { queryClient, apiRequest } from "@/lib/queryClient";
import { formatDateForAPI, formatDateForDisplay, getNextDate, getPreviousDate } from "@/lib/date";
import { HabitWithCheckIn } from "@shared/schema";

import DailyProgress from "@/components/DailyProgress";
import HabitItem from "@/components/HabitItem";
import WeeklyOverview from "@/components/WeeklyOverview";
import NewHabitModal from "@/components/NewHabitModal";

export default function Dashboard() {
  const { toast } = useToast();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [newHabitModalOpen, setNewHabitModalOpen] = useState(false);
  
  // Convert current date to API format
  const dateForApi = formatDateForAPI(currentDate);
  
  // Fetch habits for current date
  const { data: habits, isLoading, isError } = useQuery<HabitWithCheckIn[]>({
    queryKey: ['/api/habits/date', dateForApi],
    retry: 1,
  });
  
  // Mutation for toggling habit completion
  const toggleHabitMutation = useMutation({
    mutationFn: async ({ habitId, date }: { habitId: number, date: string }) => {
      return apiRequest('POST', `/api/habits/${habitId}/toggle/${date}`);
    },
    onSuccess: () => {
      // Invalidate the current date query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/habits/date', dateForApi] });
      // Also invalidate stats
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update habit: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle toggling a habit completion
  const handleToggleHabit = (habitId: number) => {
    toggleHabitMutation.mutate({ habitId, date: dateForApi });
  };
  
  // Navigate to previous day
  const goToPreviousDay = () => {
    setCurrentDate(getPreviousDate(currentDate));
  };
  
  // Navigate to next day
  const goToNextDay = () => {
    setCurrentDate(getNextDate(currentDate));
  };
  
  // Go to current day
  const goToToday = () => {
    setCurrentDate(new Date());
  };
  
  // Calculate completion rate for the progress bar
  const calculateCompletionRate = () => {
    if (!habits || habits.length === 0) return 0;
    
    const completedHabits = habits.filter(habit => habit.checkIn?.completed);
    return (completedHabits.length / habits.length) * 100;
  };
  
  return (
    <>
      {/* Date Navigation Row */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Today's Habits</h2>
        <div className="flex items-center space-x-2">
          <button 
            className="p-2 rounded-lg hover:bg-gray-200"
            onClick={goToPreviousDay}
            aria-label="Previous day"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </button>
          <div 
            className="bg-white shadow rounded-lg px-3 py-2 font-medium cursor-pointer"
            onClick={goToToday}
          >
            {formatDateForDisplay(currentDate)}
          </div>
          <button 
            className="p-2 rounded-lg hover:bg-gray-200"
            onClick={goToNextDay}
            aria-label="Next day"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>
      
      {/* Progress Overview */}
      <DailyProgress 
        completedCount={habits?.filter(h => h.checkIn?.completed).length || 0}
        totalCount={habits?.length || 0}
        progressPercentage={calculateCompletionRate()}
      />
      
      {/* Habit List */}
      <div className="space-y-4 mt-6">
        {isLoading && (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}
        
        {isError && (
          <div className="bg-red-50 text-red-500 rounded-lg p-4 text-center">
            Failed to load habits. Please try again.
          </div>
        )}
        
        {!isLoading && !isError && habits && habits.length === 0 && (
          <div className="bg-white rounded-xl shadow-sm p-8 text-center">
            <p className="text-gray-500 mb-4">No habits for this day.</p>
            <button
              className="px-4 py-2 bg-primary text-white rounded-lg"
              onClick={() => setNewHabitModalOpen(true)}
            >
              Create your first habit
            </button>
          </div>
        )}
        
        {!isLoading && !isError && habits && habits.map((habit) => (
          <HabitItem
            key={habit.id}
            habit={habit}
            onToggle={() => handleToggleHabit(habit.id)}
          />
        ))}
        
        {/* "Add Habit" button (mobile only) */}
        <button 
          className="md:hidden w-full bg-white rounded-xl shadow-sm p-4 border-2 border-dashed border-gray-300 text-gray-500 flex items-center justify-center"
          onClick={() => setNewHabitModalOpen(true)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Add New Habit
        </button>
      </div>
      
      {/* Weekly Overview Section */}
      <WeeklyOverview />
      
      {/* New Habit Modal */}
      <NewHabitModal
        isOpen={newHabitModalOpen}
        onClose={() => setNewHabitModalOpen(false)}
      />
    </>
  );
}
