import { HabitWithCheckIn } from "@shared/schema";
import { getCategoryColor, getCategoryIcon } from "@/lib/utils";
import { Heart, Book, Pen, Star, Check, Flame } from "lucide-react";

interface HabitItemProps {
  habit: HabitWithCheckIn;
  onToggle: () => void;
}

export default function HabitItem({ habit, onToggle }: HabitItemProps) {
  const categoryColor = getCategoryColor(habit.category);
  const isCompleted = habit.checkIn?.completed || false;
  
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="flex flex-col sm:flex-row">
        <div className={`w-2 sm:w-3 bg-${categoryColor} flex-shrink-0`}></div>
        <div className="flex-1 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start mb-3 sm:mb-0">
            <div className={`flex-shrink-0 h-10 w-10 rounded-full bg-${categoryColor} bg-opacity-10 flex items-center justify-center`}>
              {(() => {
                const iconName = getCategoryIcon(habit.category);
                switch (iconName) {
                  case 'heart': return <Heart className="h-5 w-5" />;
                  case 'book': return <Book className="h-5 w-5" />;
                  case 'pen': return <Pen className="h-5 w-5" />;
                  case 'star': 
                  default: return <Star className="h-5 w-5" />;
                }
              })()}
            </div>
            <div className="ml-4">
              <h4 className="text-lg font-medium">{habit.name}</h4>
              <p className="text-sm text-gray-500">{habit.description}</p>
            </div>
          </div>
          <div className="flex flex-row sm:flex-col items-center sm:items-end gap-3">
            <div className="text-sm flex items-center" title="Current streak">
              <Flame className="h-4 w-4 text-orange-500 mr-1" />
              <span>{habit.streak} days</span>
            </div>
            <button 
              className={`h-10 w-10 rounded-full flex items-center justify-center ${
                isCompleted 
                  ? `bg-${categoryColor} bg-opacity-10 hover:bg-opacity-20` 
                  : `bg-gray-100 hover:bg-gray-200`
              } transition-all duration-200`}
              onClick={onToggle}
            >
              <Check 
                className={`h-6 w-6 ${isCompleted ? `text-${categoryColor}` : 'text-gray-400'}`}
                fill={isCompleted ? "currentColor" : "none"}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
