import { Link, useLocation } from 'wouter';

interface SidebarProps {}

export default function Sidebar({}: SidebarProps) {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  const getLinkClass = (path: string) => {
    return `flex items-center px-4 py-3 ${
      isActive(path) 
        ? 'text-primary bg-blue-50' 
        : 'text-gray-600 hover:bg-gray-100'
    } rounded-lg mb-1`;
  };
  
  return (
    <div className="hidden md:flex md:flex-col md:w-64 bg-white border-r border-gray-200 p-4">
      <div className="flex items-center mb-8">
        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
          </svg>
        </div>
        <span className="ml-3 text-xl font-semibold">ElectroAnalyzer</span>
      </div>
      
      <nav className="flex-1">
        <Link href="/electronic-analyzer" className={getLinkClass('/electronic-analyzer')}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
          </svg>
          Analizador de Componentes
        </Link>
      </nav>
      
      <div className="mt-auto pt-4">
        <div className="bg-blue-50 rounded-lg p-4">
          <h4 className="font-medium text-primary mb-2">Análisis Avanzado</h4>
          <p className="text-sm text-gray-600 mb-3">Usando inteligencia artificial para detectar componentes electrónicos con precisión.</p>
        </div>
      </div>
    </div>
  );
}
