import { Link, useLocation } from 'wouter';

interface MobileNavProps {}

export default function MobileNav({}: MobileNavProps) {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  const getLinkClass = (path: string) => {
    return `flex flex-col items-center py-3 ${
      isActive(path) ? 'text-primary' : 'text-gray-500'
    }`;
  };
  
  return (
    <div className="md:hidden bg-white border-t border-gray-200 fixed bottom-0 left-0 right-0 z-10">
      <div className="flex justify-around">
        <Link href="/electronic-analyzer" className={getLinkClass('/electronic-analyzer')}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
          </svg>
          <span className="text-xs mt-1">Analizador</span>
        </Link>
      </div>
    </div>
  );
}
