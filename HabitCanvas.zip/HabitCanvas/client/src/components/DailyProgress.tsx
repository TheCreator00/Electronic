interface DailyProgressProps {
  completedCount: number;
  totalCount: number;
  progressPercentage: number;
}

export default function DailyProgress({
  completedCount,
  totalCount,
  progressPercentage
}: DailyProgressProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
        <h3 className="text-lg font-semibold mb-2 md:mb-0">Daily Progress</h3>
        <div className="text-sm font-medium">
          <span className="text-primary">{completedCount}</span> completed out of <span className="text-gray-600">{totalCount}</span> habits
        </div>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div 
          className="bg-primary h-2.5 rounded-full" 
          style={{ width: `${progressPercentage}%` }}
        ></div>
      </div>
    </div>
  );
}
