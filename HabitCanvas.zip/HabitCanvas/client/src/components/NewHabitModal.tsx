import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

import { queryClient, apiRequest } from "@/lib/queryClient";
import { CreateHabit } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface NewHabitModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NewHabitModal({ isOpen, onClose }: NewHabitModalProps) {
  const { toast } = useToast();
  
  // Form state
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string>("health");
  const [reminderTime, setReminderTime] = useState<string>("");
  const [frequency, setFrequency] = useState({
    monday: true,
    tuesday: true,
    wednesday: true,
    thursday: true,
    friday: true,
    saturday: true,
    sunday: true,
  });
  
  // Create habit mutation
  const createHabitMutation = useMutation({
    mutationFn: async (newHabit: CreateHabit) => {
      return apiRequest('POST', '/api/habits', newHabit);
    },
    onSuccess: () => {
      toast({
        title: "Habit created",
        description: "Your new habit has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create habit: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Validation error",
        description: "Habit name is required.",
        variant: "destructive",
      });
      return;
    }
    
    // Create new habit data
    const newHabit: CreateHabit = {
      name,
      description,
      category,
      reminderTime: reminderTime ? new Date(`1970-01-01T${reminderTime}:00`) : null,
      frequency,
      userId: undefined,
    };
    
    createHabitMutation.mutate(newHabit);
  };
  
  // Reset form to default values
  const resetForm = () => {
    setName("");
    setDescription("");
    setCategory("health");
    setReminderTime("");
    setFrequency({
      monday: true,
      tuesday: true,
      wednesday: true,
      thursday: true,
      friday: true,
      saturday: true,
      sunday: true,
    });
  };
  
  // Handle day toggle in frequency
  const handleDayToggle = (day: keyof typeof frequency) => {
    setFrequency(prev => ({
      ...prev,
      [day]: !prev[day],
    }));
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Habit</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Habit Name */}
          <div>
            <Label htmlFor="habitName">Habit Name</Label>
            <Input
              id="habitName"
              placeholder="e.g., Morning Meditation"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          
          {/* Habit Description */}
          <div>
            <Label htmlFor="habitDescription">Description (Optional)</Label>
            <Textarea
              id="habitDescription"
              placeholder="e.g., 10 minutes of mindfulness meditation"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
            />
          </div>
          
          {/* Category */}
          <div>
            <Label>Category</Label>
            <div className="grid grid-cols-4 gap-2 mt-1">
              <CategoryOption
                id="cat1"
                value="health"
                label="Health"
                checked={category === "health"}
                onChange={() => setCategory("health")}
              />
              <CategoryOption
                id="cat2"
                value="learning"
                label="Learning"
                checked={category === "learning"}
                onChange={() => setCategory("learning")}
              />
              <CategoryOption
                id="cat3"
                value="productivity"
                label="Work"
                checked={category === "productivity"}
                onChange={() => setCategory("productivity")}
              />
              <CategoryOption
                id="cat4"
                value="other"
                label="Other"
                checked={category === "other"}
                onChange={() => setCategory("other")}
              />
            </div>
          </div>
          
          {/* Frequency */}
          <div>
            <Label>Repeat</Label>
            <div className="grid grid-cols-7 gap-1 mt-1">
              <DayToggle
                id="day1"
                label="S"
                checked={frequency.sunday}
                onChange={() => handleDayToggle("sunday")}
              />
              <DayToggle
                id="day2"
                label="M"
                checked={frequency.monday}
                onChange={() => handleDayToggle("monday")}
              />
              <DayToggle
                id="day3"
                label="T"
                checked={frequency.tuesday}
                onChange={() => handleDayToggle("tuesday")}
              />
              <DayToggle
                id="day4"
                label="W"
                checked={frequency.wednesday}
                onChange={() => handleDayToggle("wednesday")}
              />
              <DayToggle
                id="day5"
                label="T"
                checked={frequency.thursday}
                onChange={() => handleDayToggle("thursday")}
              />
              <DayToggle
                id="day6"
                label="F"
                checked={frequency.friday}
                onChange={() => handleDayToggle("friday")}
              />
              <DayToggle
                id="day7"
                label="S"
                checked={frequency.saturday}
                onChange={() => handleDayToggle("saturday")}
              />
            </div>
          </div>
          
          {/* Reminder Time */}
          <div>
            <Label htmlFor="reminderTime">Reminder Time (Optional)</Label>
            <Input
              id="reminderTime"
              type="time"
              value={reminderTime}
              onChange={(e) => setReminderTime(e.target.value)}
            />
          </div>
          
          {/* Submit Button */}
          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={createHabitMutation.isPending}>
              {createHabitMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Create Habit
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Helper component for category selection
function CategoryOption({ id, value, label, checked, onChange }: { 
  id: string; 
  value: string; 
  label: string; 
  checked: boolean; 
  onChange: () => void;
}) {
  const getColorClass = () => {
    switch (value) {
      case 'health': return 'bg-success';
      case 'learning': return 'bg-secondary';
      case 'productivity': return 'bg-primary';
      case 'other': return 'bg-warning';
      default: return 'bg-gray-300';
    }
  };
  
  const getBorderColor = () => {
    switch (value) {
      case 'health': return 'border-success';
      case 'learning': return 'border-secondary';
      case 'productivity': return 'border-primary';
      case 'other': return 'border-warning';
      default: return 'border-gray-200';
    }
  };
  
  const getBackgroundClass = () => {
    switch (value) {
      case 'health': return 'bg-green-50';
      case 'learning': return 'bg-purple-50';
      case 'productivity': return 'bg-blue-50';
      case 'other': return 'bg-yellow-50';
      default: return 'bg-white';
    }
  };
  
  return (
    <div className="relative">
      <input
        type="radio"
        name="category"
        id={id}
        value={value}
        className="peer sr-only"
        checked={checked}
        onChange={onChange}
      />
      <label
        htmlFor={id}
        className={`flex flex-col items-center p-2 bg-white border-2 border-gray-200 rounded-lg cursor-pointer peer-checked:${getBorderColor()} peer-checked:${getBackgroundClass()} hover:bg-gray-50`}
      >
        <span className={`w-6 h-6 ${getColorClass()} rounded-full mb-1`}></span>
        <span className="text-xs">{label}</span>
      </label>
    </div>
  );
}

// Helper component for day toggle
function DayToggle({ id, label, checked, onChange }: {
  id: string;
  label: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <div className="relative">
      <input
        type="checkbox"
        name="days"
        id={id}
        className="peer sr-only"
        checked={checked}
        onChange={onChange}
      />
      <label
        htmlFor={id}
        className="flex items-center justify-center h-9 bg-white border border-gray-200 rounded-lg cursor-pointer peer-checked:bg-primary peer-checked:text-white hover:bg-gray-50"
      >
        <span className="text-xs font-medium">{label}</span>
      </label>
    </div>
  );
}
