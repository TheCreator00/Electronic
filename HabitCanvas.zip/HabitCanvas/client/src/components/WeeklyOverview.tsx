import { useState } from 'react';
import CalendarView from './CalendarView';
import StatsCard from './StatsCard';
import { useQuery } from '@tanstack/react-query';
import { HabitStats } from '@shared/schema';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { getDaysInMonth } from '@/lib/date';
import { Loader2 } from 'lucide-react';
import { formatPercentage } from '@/lib/utils';

export default function WeeklyOverview() {
  const [currentMonth] = useState(new Date());
  
  // Fetch habit stats
  const { data: stats, isLoading: statsLoading } = useQuery<HabitStats>({
    queryKey: ['/api/stats'],
  });
  
  // Fetch habits for calendar view
  const { data: habits, isLoading: habitsLoading } = useQuery({
    queryKey: ['/api/habits'],
  });
  
  const isLoading = statsLoading || habitsLoading;
  const daysInMonth = getDaysInMonth(currentMonth);
  
  return (
    <div className="mt-8">
      <h3 className="text-xl font-bold mb-4">Weekly Overview</h3>
      
      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Calendar View */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h4 className="font-medium text-gray-800 mb-4">{format(currentMonth, 'MMMM yyyy')}</h4>
            <CalendarView
              month={currentMonth}
              days={daysInMonth.slice(0, 35)} // Limit to 5 weeks for weekly overview
              habits={habits || []}
              isCompact={true}
            />
          </div>
          
          {/* Stats Card */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h4 className="font-medium text-gray-800 mb-4">Your Statistics</h4>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="text-sm text-gray-600 mb-1">Completion Rate</div>
                <div className="text-2xl font-bold text-primary">
                  {stats ? formatPercentage(stats.completionRate) : '0%'}
                </div>
              </div>
              <div className="bg-purple-50 rounded-lg p-4">
                <div className="text-sm text-gray-600 mb-1">Best Streak</div>
                <div className="text-2xl font-bold text-secondary">
                  {stats ? `${stats.bestStreak} days` : '0 days'}
                </div>
              </div>
            </div>
            
            <h5 className="font-medium text-gray-700 mb-3">Habit Trends</h5>
            <div className="space-y-3">
              {stats && stats.habitTrends.slice(0, 3).map((trend) => (
                <div key={trend.habitId}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{trend.habitName}</span>
                    <span className={`text-${trend.category === 'health' ? 'success' : trend.category === 'learning' ? 'secondary' : 'primary'} font-medium`}>
                      {formatPercentage(trend.completionRate)}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div 
                      className={`bg-${trend.category === 'health' ? 'success' : trend.category === 'learning' ? 'secondary' : 'primary'} h-1.5 rounded-full`} 
                      style={{ width: `${trend.completionRate}%` }}
                    ></div>
                  </div>
                </div>
              ))}
              
              {(!stats || stats.habitTrends.length === 0) && (
                <div className="text-center text-gray-500 py-2">
                  No habit data available yet.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
