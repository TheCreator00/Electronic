interface StatsCardProps {
  title: string;
  value: string;
  description: string;
  color?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger';
}

export default function StatsCard({ 
  title, 
  value, 
  description, 
  color = 'primary' 
}: StatsCardProps) {
  const getBackgroundColor = () => {
    switch (color) {
      case 'primary': return 'bg-blue-50';
      case 'secondary': return 'bg-purple-50';
      case 'success': return 'bg-green-50';
      case 'warning': return 'bg-yellow-50';
      case 'danger': return 'bg-red-50';
      default: return 'bg-blue-50';
    }
  };
  
  const getTextColor = () => {
    switch (color) {
      case 'primary': return 'text-primary';
      case 'secondary': return 'text-secondary';
      case 'success': return 'text-success';
      case 'warning': return 'text-warning';
      case 'danger': return 'text-danger';
      default: return 'text-primary';
    }
  };
  
  return (
    <div className={`${getBackgroundColor()} rounded-xl shadow-sm p-6`}>
      <h3 className="text-gray-700 font-medium mb-2">{title}</h3>
      <p className={`text-3xl font-bold ${getTextColor()} mb-1`}>{value}</p>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
  );
}
