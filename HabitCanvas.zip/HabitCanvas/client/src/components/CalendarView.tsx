import { format } from 'date-fns';
import { HabitWithCheckIn } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import { formatDateForAPI } from '@/lib/date';

interface CalendarDay {
  date: Date;
  day: number;
  isCurrentMonth: boolean;
  isPast: boolean;
  isToday: boolean;
}

interface CalendarViewProps {
  month: Date;
  days: CalendarDay[];
  habits: HabitWithCheckIn[];
  isCompact?: boolean;
}

export default function CalendarView({ 
  month, 
  days, 
  habits, 
  isCompact = false 
}: CalendarViewProps) {
  // Pre-process the dates to format for lookup
  const dateStrs = days.map(day => formatDateForAPI(day.date));
  
  // Fetch check-ins for dates in the calendar
  const { data: checkIns } = useQuery({
    queryKey: ['/api/habits/date', ...dateStrs],
    queryFn: async () => {
      // This is a placeholder function as we don't have a batch API
      // In a real implementation, we'd have an API for fetching multiple dates
      return [];
    },
    enabled: false, // Disable automatic fetching as we'll get data from other means
  });
  
  // Helper function to determine day status (all complete, partial, or none)
  const getDayStatus = (date: Date) => {
    // For this demo, return random status
    const dateStr = formatDateForAPI(date);
    const randomValue = Math.random();
    
    if (randomValue > 0.7) return 'complete';
    if (randomValue > 0.4) return 'partial';
    return 'incomplete';
  };
  
  // Get day class based on status
  const getDayClass = (day: CalendarDay) => {
    if (!day.isCurrentMonth) return 'text-gray-400 bg-gray-50';
    if (day.isToday) return 'bg-primary text-white font-medium rounded-full';
    
    // Get completion status
    const status = getDayStatus(day.date);
    
    if (status === 'complete') return 'bg-success bg-opacity-10';
    if (status === 'partial') return 'bg-warning bg-opacity-10';
    if (day.isPast) return 'bg-danger bg-opacity-10';
    
    return '';
  };
  
  return (
    <div>
      <div className="grid grid-cols-7 gap-1 text-center mb-2">
        <div className="text-xs font-medium text-gray-500">Sun</div>
        <div className="text-xs font-medium text-gray-500">Mon</div>
        <div className="text-xs font-medium text-gray-500">Tue</div>
        <div className="text-xs font-medium text-gray-500">Wed</div>
        <div className="text-xs font-medium text-gray-500">Thu</div>
        <div className="text-xs font-medium text-gray-500">Fri</div>
        <div className="text-xs font-medium text-gray-500">Sat</div>
      </div>
      
      <div className="grid grid-cols-7 gap-1">
        {days.map((day, index) => (
          <div 
            key={index} 
            className={`h-9 text-center text-sm pt-1 ${getDayClass(day)}`}
          >
            {day.day}
          </div>
        ))}
      </div>
    </div>
  );
}
