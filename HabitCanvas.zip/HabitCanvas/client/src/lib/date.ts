import { format, parseISO, isToday, isYesterday, isTomorrow, addDays, subDays, isSameDay } from "date-fns";

// Format a date as YYYY-MM-DD
export function formatDateForAPI(date: Date): string {
  return format(date, "yyyy-MM-dd");
}

// Format a date in a human-readable way
export function formatDateForDisplay(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  
  if (isToday(dateObj)) {
    return "Today";
  } else if (isYesterday(dateObj)) {
    return "Yesterday";
  } else if (isTomorrow(dateObj)) {
    return "Tomorrow";
  } else {
    return format(dateObj, "MMMM d, yyyy");
  }
}

// Get day of week as string
export function getDayOfWeek(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return format(dateObj, "EEEE");
}

// Get the day index (0 = Sunday, 1 = Monday, etc.)
export function getDayIndex(date: Date | string): number {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return dateObj.getDay();
}

// Check if a date is in the past
export function isPastDate(date: Date | string): boolean {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return dateObj < today;
}

// Get the start and end dates for a given month
export function getMonthBoundaries(date: Date) {
  const year = date.getFullYear();
  const month = date.getMonth();
  
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  
  return { firstDay, lastDay };
}

// Get days array for a month (including prev/next month days to fill the grid)
export function getDaysInMonth(date: Date) {
  const { firstDay, lastDay } = getMonthBoundaries(date);
  
  // Get the number of days in the month
  const daysInMonth = lastDay.getDate();
  
  // Get the first day of the week of the month (0 = Sunday, 1 = Monday, etc.)
  const firstDayOfWeek = firstDay.getDay();
  
  // Calculate days from previous month to display
  const daysFromPrevMonth = firstDayOfWeek;
  
  // Calculate days from next month to display (to fill a 6-week grid)
  const totalCells = 42; // 6 weeks × 7 days
  const daysFromNextMonth = totalCells - daysInMonth - daysFromPrevMonth;
  
  // Create the days array
  const daysArray = [];
  
  // Add days from previous month
  const prevMonthLastDay = new Date(firstDay);
  prevMonthLastDay.setDate(0);
  const prevMonthDays = prevMonthLastDay.getDate();
  
  for (let i = daysFromPrevMonth - 1; i >= 0; i--) {
    const day = prevMonthDays - i;
    const date = new Date(firstDay);
    date.setDate(1 - daysFromPrevMonth + (daysFromPrevMonth - i - 1));
    daysArray.push({
      date,
      day,
      isCurrentMonth: false,
      isPast: isPastDate(date),
      isToday: isToday(date)
    });
  }
  
  // Add days from current month
  for (let i = 1; i <= daysInMonth; i++) {
    const date = new Date(firstDay);
    date.setDate(i);
    daysArray.push({
      date,
      day: i,
      isCurrentMonth: true,
      isPast: isPastDate(date),
      isToday: isToday(date)
    });
  }
  
  // Add days from next month
  for (let i = 1; i <= daysFromNextMonth; i++) {
    const date = new Date(lastDay);
    date.setDate(lastDay.getDate() + i);
    daysArray.push({
      date,
      day: i,
      isCurrentMonth: false,
      isPast: false,
      isToday: isToday(date)
    });
  }
  
  return daysArray;
}

// Get previous date
export function getPreviousDate(date: Date): Date {
  return subDays(date, 1);
}

// Get next date
export function getNextDate(date: Date): Date {
  return addDays(date, 1);
}
