import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Category-related helpers
export type HabitCategory = 'health' | 'learning' | 'productivity' | 'other';

export function getCategoryColor(category: HabitCategory | string): string {
  switch (category) {
    case 'health':
      return 'success';
    case 'learning':
      return 'secondary';
    case 'productivity':
      return 'primary';
    case 'other':
    default:
      return 'warning';
  }
}

export function getCategoryIcon(category: HabitCategory | string): string {
  switch (category) {
    case 'health':
      return 'heart';
    case 'learning':
      return 'book';
    case 'productivity':
      return 'pen';
    case 'other':
    default:
      return 'star';
  }
}

// Format percentage for display
export function formatPercentage(value: number): string {
  return `${Math.round(value)}%`;
}
