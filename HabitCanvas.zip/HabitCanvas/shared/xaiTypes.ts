export interface KnowledgeDocument {
  id: string;
  name: string;
  type: 'pdf' | 'txt' | 'doc' | 'image';
  path: string;
  addedAt: Date;
  description?: string;
  tags: string[];
  status: 'processing' | 'ready' | 'error';
  content?: string; // Contenido procesado del documento
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
  attachments?: {
    type: 'image' | 'file';
    url: string;
    name: string;
  }[];
}

export interface ChatRequest {
  message: string;
  model: 'grok' | 'local' | 'hybrid';
  attachments?: {
    type: 'image' | 'file';
    data: string; // Base64 para imágenes, texto para archivos
    name: string;
  }[];
  documentIds?: string[]; // IDs de documentos de la base de conocimiento a utilizar
}

export interface ChatResponse {
  message: string;
  attachments?: {
    type: 'image' | 'file';
    data: string;
    name: string;
  }[];
  usedDocuments?: string[]; // IDs de los documentos utilizados para la respuesta
  processingTime?: number;
  confidence?: number;
}

export interface ModelStatusResponse {
  grok: boolean;
  local: boolean;
  hybrid: boolean;
  message: string;
}

export interface DocumentUploadResponse {
  document: KnowledgeDocument;
  message: string;
}