import { pgTable, text, serial, integer, boolean, date, time } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema remains (not needed for now but keeping for future expansion)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Habits schema
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // health, learning, productivity, other
  createdAt: date("created_at").notNull().defaultNow(),
  reminderTime: time("reminder_time"),
  userId: integer("user_id"),
});

// Days of the week for habits
export const habitFrequencies = pgTable("habit_frequencies", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull(),
  monday: boolean("monday").notNull().default(false),
  tuesday: boolean("tuesday").notNull().default(false),
  wednesday: boolean("wednesday").notNull().default(false),
  thursday: boolean("thursday").notNull().default(false),
  friday: boolean("friday").notNull().default(false),
  saturday: boolean("saturday").notNull().default(false),
  sunday: boolean("sunday").notNull().default(false),
});

// Habit check-ins (completions)
export const habitCheckIns = pgTable("habit_check_ins", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull(),
  date: date("date").notNull(),
  completed: boolean("completed").notNull().default(false),
  userId: integer("user_id"),
});

// Create Zod schemas for insertion
export const insertHabitSchema = createInsertSchema(habits).omit({
  id: true,
  createdAt: true,
});

export const insertFrequencySchema = createInsertSchema(habitFrequencies).omit({
  id: true,
});

export const insertCheckInSchema = createInsertSchema(habitCheckIns).omit({
  id: true,
});

// Combined schema for creating a habit with frequency
export const createHabitSchema = insertHabitSchema.extend({
  frequency: z.object({
    monday: z.boolean().default(false),
    tuesday: z.boolean().default(false),
    wednesday: z.boolean().default(false),
    thursday: z.boolean().default(false),
    friday: z.boolean().default(false),
    saturday: z.boolean().default(false),
    sunday: z.boolean().default(false),
  }),
});

// Types for TypeScript
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type HabitFrequency = typeof habitFrequencies.$inferSelect;
export type InsertHabitFrequency = z.infer<typeof insertFrequencySchema>;
export type HabitCheckIn = typeof habitCheckIns.$inferSelect;
export type InsertHabitCheckIn = z.infer<typeof insertCheckInSchema>;
export type CreateHabit = z.infer<typeof createHabitSchema>;

// Combined habit with frequency
export type HabitWithFrequency = Habit & {
  frequency: HabitFrequency;
};

// Habit with check-in status for a specific date
export type HabitWithCheckIn = Habit & {
  frequency: HabitFrequency;
  checkIn?: HabitCheckIn;
  streak: number;
};

// Stats for habits
export type HabitStats = {
  completionRate: number;
  bestStreak: number;
  currentStreak: number;
  habitTrends: {
    habitId: number;
    habitName: string;
    category: string;
    completionRate: number;
  }[];
};
